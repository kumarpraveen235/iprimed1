import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Student } from '../models/student';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  // API path
  base_path = 'http://localhost:8888/CRUDREST/users';

  constructor(private http: HttpClient) { }

  // Http Options
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  // Handle API errors

  // Create a new item
  createItem(item:Student): Observable<Student> {
    return this.http
      .post<Student>(this.base_path, JSON.stringify(item),
       this.httpOptions)
      
  }

  // Get single student data by ID
  getItem(id:number): Observable<Student> {
    return this.http
      .get<Student>(this.base_path + '/' + id)
      
  }

  // Get students data
  getList(): Observable<Student> {
    return this.http
      .get<Student>(this.base_path)
      
  }

  // Update item by id
  updateItem(id:number, item:Student): Observable<Student> {
    return this.http
      .put<Student>(this.base_path + '/' + id, JSON.stringify(item), this.httpOptions)
      
  }

  // Delete item by id
  deleteItem(id:number) {
    return this.http
      .delete<Student>(this.base_path + '/' + id, this.httpOptions)
      


  }

}
 