export class Student {
    id: number=0;
    name: string="";
    des: string="";
    age: number=0;
    dob:string="";
 } 