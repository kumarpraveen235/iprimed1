package praveen;
import java.io.*;
public class THree {
public static void main(String[] args) {
	FileOutputStream fout=null;
	FileInputStream fin=null;
	String  s="welcome to bangalore";
	try
	{
		 fout=new FileOutputStream("a.txt");
		byte[] b=s.getBytes();
		fout.write(b);
	System.out.println("written");
	 fin=new FileInputStream("a.txt");
	int i=0;
	while((i=fin.read())!=-1)
	{
		System.out.print((char)i);
	}
	}
	catch(Exception e)
	{
		System.out.println("handeled");
	}
	finally {
		       try {  fin.close();fout.close();}
		       catch (Exception e) {
			System.out.println("handeled  "+e);
			}
	}
}
}
