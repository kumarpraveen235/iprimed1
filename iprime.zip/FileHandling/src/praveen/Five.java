package praveen;
import java.io.*;
public class Five {
public static void main(String[] args) throws IOException {
	FileInputStream  fin1=new FileInputStream("a.txt");
	FileInputStream  fin2=new FileInputStream("b.txt");
	SequenceInputStream  s=new SequenceInputStream(fin1,fin2);
	int i=0;
	while((i=s.read())!=-1)
	{
		System.out.print((char)i);
	}
}
}
