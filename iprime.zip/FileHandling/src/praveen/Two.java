package praveen;
import  java.io.*;
public class Two {
public static void main(String[] args) throws IOException {
	FileOutputStream  fout=new FileOutputStream("f1.txt", true);
	String  s="today is monday";
	byte[] b=s.getBytes();
	fout.write(b);
	System.out.println("written");
}
}
