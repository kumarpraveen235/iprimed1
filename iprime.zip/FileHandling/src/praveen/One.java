package praveen;
import java.io.*;
public class One {
public static void main(String[] args) throws  IOException
{
	File f=new File("ip.txt");
	System.out.println(f.createNewFile());
	System.out.println(f.isFile());
	System.out.println(f.isDirectory());
	System.out.println(f.getCanonicalPath());
	System.out.println(f.getAbsolutePath());
	System.out.println(f.getFreeSpace());
	System.out.println(f.delete());
	
}
}
