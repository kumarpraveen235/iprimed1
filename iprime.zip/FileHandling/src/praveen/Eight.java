package praveen;

import java.io.IOException;
import java.io.PrintStream;

public class Eight {
public static void main(String[] args) throws IOException {
	PrintStream  ps=new PrintStream(System.out, true);
	ps.println("i am praveen");
	ps.println(false);
	char[]c = {'w','e','l','c','o','m','e'};
	ps.println(c);
	ps.println(6868.879);
	
}
}
