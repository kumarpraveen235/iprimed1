package praveen;
import java.io.*;
public class Seven {
public static void main(String[] args) throws IOException {
	FileInputStream  finn=new FileInputStream("d:\\f1.txt");
	int i =0;
	finn.skip(9);
	while((i=finn.read())!=-1)
	{
		System.out.print((char)i);
	}
}
}
