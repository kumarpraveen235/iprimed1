package praveen;
import java.io.*;
public class Six {
public static void main(String[] args) {
	String s="This is SpringAngular training";
	byte[]  b=s.getBytes();
	ByteArrayInputStream  ba=new ByteArrayInputStream(b,8,14);
	int i=0;
	while((i=ba.read())!=-1)
	{
		System.out.print((char)i);
	}
}
}
