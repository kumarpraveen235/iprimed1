package praveen;
import java.io.*;
public class Four {
public static void main(String[] args) throws IOException{
	FileOutputStream  f  =new FileOutputStream("b.txt");
	BufferedOutputStream  b=new BufferedOutputStream(f, 1024);
	byte[] bt="hi hello how are you".getBytes();
	b.write(bt);
	b.flush();
	System.out.println("written");
}
}
