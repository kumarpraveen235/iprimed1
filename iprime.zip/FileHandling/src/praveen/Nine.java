package praveen;
import java.io.*;
 class Student  implements Serializable{
    int id;
    String name;
    int age;
	public Student(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
    
}
 public class Nine{
	 public static void main(String[] args) throws Exception{
			/*
			 * Student s=new Student(1, "ravi", 22); FileOutputStream fout=new
			 * FileOutputStream("ser.txt"); ObjectOutputStream o=new
			 * ObjectOutputStream(fout); o.writeObject(s); o.flush();
			 * System.out.println("successfully serialized!!");
			 */
		 
	 FileInputStream  fin=new FileInputStream("ser.txt");
	 ObjectInputStream  oi=new ObjectInputStream(fin);
	 Student  ss=(Student)oi.readObject();
	 System.out.println(ss.id+"   "+ss.name+"    "+ss.age);
	 }
	 
	 
 }
