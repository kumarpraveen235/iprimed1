import  java.util.*;
public class First<T> {
	
	T obj;

	public T getObj() {
		return obj;
	}

	public void setObj(T obj) {
		this.obj = obj;
	}
	public static void main(String[] args) {
		First<Double>  f=new First<Double>();
		f.setObj(10.979);
		System.out.println(f.getObj());
	}

}
