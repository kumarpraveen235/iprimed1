package praveen;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.*;
public class Two {
public static void main(String[] args) {
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection  conn=DriverManager.getConnection
			("jdbc:mysql://localhost:3306/iprimed", "root", "123456");
	
	System.out.println("Connected   "+conn);
	Scanner  sc=new Scanner(System.in);
	System.out.println("enter  book id, name and price");
	int id=sc.nextInt();
	String name=sc.next();
	double  price=sc.nextDouble();
	String str="insert into book  values("+id+", '"+name+"', "+price+")";
	Statement st=conn.createStatement();
	int r=st.executeUpdate(str);
	System.out.println(r+"   rows inserted!!!");
		}
	catch (Exception e) {
	System.out.println("Connection issue   "+e);	
	}
	
}
}
