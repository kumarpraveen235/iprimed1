package praveen;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.*;
public class Three {
public static void main(String[] args) {
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection  conn=DriverManager.getConnection
			("jdbc:mysql://localhost:3306/iprimed", "root", "123456");
	
System.out.println("connected");
//String ss="update   book   set name='css',  price=300.00  where  id=3";
String ss="delete  from book  where id=2";
Statement  st=conn.createStatement();
  System.out.println(st.executeUpdate(ss)+"   ROW Deleted!!! ");
	}
	catch (Exception e) {
		// TODO: handle exception
	}
}}