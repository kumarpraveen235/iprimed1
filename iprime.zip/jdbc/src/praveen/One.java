package praveen;
import java.sql.*;
public class One {
public static void main(String[] args) {
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection  conn=DriverManager.getConnection
			("jdbc:mysql://localhost:3306/iprimed", "root", "123456");
	//   3306 is port of  mysql
	// root is username of mysql  123456 is a password of mysql
	System.out.println("Connected   "+conn);
	/*
	 * String
	 * s="create table book(id int(3), name varchar(10), price  decimal(10,5))";
	 * Statement st=conn.createStatement(); st.executeUpdate(s);
	 * System.out.println("created  the table successfully");
	 */
	String str="insert into book values(2, 'java', 838.758)";
	String str1="insert into book values(3, 'spring', 777.758)";
	String str2="insert into book values(4, 'python', 666.758)";
	Statement st=conn.createStatement(); 
	int  r=st.executeUpdate(str);System.out.println(r+"    rows inserted!");
	int  r1=st.executeUpdate(str1);System.out.println(r1+"    rows inserted!");
	int  r2=st.executeUpdate(str2);
	 System.out.println(r2+"    rows inserted!");
	}
	catch (Exception e) {
	System.out.println("Connection issue   "+e);	
	}
	
}
}
