package praveen;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
public class Ten {
public static void main(String[] args) {
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection  conn=DriverManager.getConnection
			("jdbc:mysql://localhost:3306/iprimed", "root", "123456");
	System.out.println("connected");
Scanner  sc=new Scanner(System.in);
System.out.println("enter array  size ");
int n=sc.nextInt();
int  id[]=new int[n];
String name[]=new String[n];
double  price[]=new double[n];
System.out.println("enter the  "+n+"   book id, name and price");
for(int  i=0; i<n;i++)
{
	    id[i]=sc.nextInt();
	    name[i]=sc.next();
	    price[i]=sc.nextDouble();
	PreparedStatement  pst=conn.prepareStatement
			("insert into book values(?,?,?)");
	pst.setInt(1, id[i]);
	pst.setString(2, name[i]);
	pst.setDouble(3, price[i]);
	pst.executeUpdate();
}
System.out.println("sucecssfully inserted");
System.out.println("book   table  data");
PreparedStatement pst1=conn.prepareStatement("select * from book");
ResultSet   r=pst1.executeQuery();
while(r.next())
{
	System.out.println(r.getString(1)+"  "+r.getString(2)+"  "+r.getString(3));
}

}
	catch (Exception e) {
		// TODO: handle exception
	}}}