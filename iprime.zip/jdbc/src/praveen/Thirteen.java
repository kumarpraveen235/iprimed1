package praveen;
import java.sql.*;
import java.util.*;

public class Thirteen {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter  2 no");
		int a=sc.nextInt();
		int b=sc.nextInt();
		try
		{
			Connection conn=ConnectionUntil.getConnection();
			System.out.println("connected! "+conn);
	String s="call adding1(?,?,?)";
	CallableStatement  cst=conn.prepareCall(s);
	cst.setInt(1, a);
	cst.setInt(2, b);
	cst.registerOutParameter(3, Types.INTEGER);
	cst.execute();
	System.out.println("sum   "+cst.getInt(3));
		}
		catch (Exception e) {
		e.printStackTrace();
		}
	}

}
