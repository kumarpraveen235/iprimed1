package praveen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
public class Nine {
public static void main(String[] args) {
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection  conn=DriverManager.getConnection
			("jdbc:mysql://localhost:3306/iprimed", "root", "123456");
	System.out.println("connected");
Scanner  sc=new Scanner(System.in);
System.out.println("enter id , name and price");
int id=sc.nextInt();
String name=sc.next();double price=sc.nextDouble();
String str="update book  set  name=?, price=? where id=? ";

PreparedStatement  pst=conn.prepareStatement(str);
   pst.setString(1, name);
   pst.setDouble(2, price);
   pst.setInt(3, id);
   System.out.println(pst.executeUpdate()+"   row updated");
   System.out.println("book   table  data");
   PreparedStatement pst1=conn.prepareStatement("select * from book");
   ResultSet   r=pst1.executeQuery();
   while(r.next())
   {
   	System.out.println(r.getString(1)+"  "+r.getString(2)+"  "+r.getString(3));
   }


	}
	catch (Exception e) {
		// TODO: handle exception
	}
}}