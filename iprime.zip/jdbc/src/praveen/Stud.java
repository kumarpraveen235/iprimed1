package praveen;
import java.util.*;
import java.sql.*;
class Student
{
	  int id;
	  String name;
	  int age;
	public Student(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	public Student() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + "]";
	}
	  
}
public class Stud {
 public static void main(String[] args) {
	 try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection  conn=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/iprimed", "root", "123456");
			System.out.println("connected");
			LinkedList<Student> l=new LinkedList<Student>();
			l.add(new Student(11, "sunny", 22));
			l.add(new Student(12, "ajay", 23));
			l.add(new Student(13, "vishal", 21));
			l.add(new Student(14, "vijay", 25));
			l.add(new Student(15, "mohan", 24));
			for(Student  s:l)
			{
				String st="insert into stud values(?,?,?)";
				
	PreparedStatement pst=conn.prepareStatement(st);
	   pst.setInt(1, s.id);
	   pst.setString(2, s.name);
	   pst.setInt(3, s.age);
			pst.executeUpdate();
		
			}
			System.out.println("inserted!!!!");
			String st="select * from stud";
			
PreparedStatement pst1=conn.prepareStatement(st);
   	ResultSet r=pst1.executeQuery();
   	ArrayList<Student> al=new ArrayList<Student>();
   	while(r.next())
   	{
   		Student   s=new Student();
   		s.setId(r.getInt(1));
   		s.setName(r.getString(2));
   		s.setAge(r.getInt(3));
   		al.add(s);
   	}
   		for(Student  st1:al)
   		{
   			System.out.println(st1);
   		}
   	}

	 catch (Exception e) {
		// TODO: handle exception
	}
}
}