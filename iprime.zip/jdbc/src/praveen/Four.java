package praveen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
public class Four {
public static void main(String[] args) {
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection  conn=DriverManager.getConnection
			("jdbc:mysql://localhost:3306/iprimed", "root", "123456");

System.out.println("connected");
String str ="insert  into book  values(8, 'jquery', 700.00)";
      Statement  st=conn.createStatement();
      System.out.println(st.executeUpdate(str)+"    Row inserted!!");
      System.out.println("data from table");
      ResultSet   r=st.executeQuery("select * from  book");
      while(r.next())
      {
    System.out.println(r.getInt(1)+"\t"+r.getString(2)+"\t"+r.getDouble(3));
      }
	}
	catch(Exception e)
	{
		
		e.printStackTrace();
	}
}}