package praveen;
import java.sql.*;

public class Seven {
public static void main(String[] args) {
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection  conn=DriverManager.getConnection
			("jdbc:mysql://localhost:3306/iprimed", "root", "123456");

System.out.println("connected");
   Statement  st=conn.createStatement();
   st.addBatch("insert into book values(1,'java',777.00)");
   st.addBatch("insert into book values(2,'dotnet',677.00)");
   st.addBatch("update book set name='ruby', price=555.00 where id=8");
   st.addBatch("delete  from book where id=7");
   
   st.executeBatch();
   System.out.println("Executed!!");
   System.out.println("data  from table");
   ResultSet rr=st.executeQuery("select * from book");
   while(rr.next())
   {
	   System.out.println(rr.getString(1)+"  "+rr.getString(2)+"  "+rr.getString(3));
   }
}
	catch (Exception e) {
		// TODO: handle exception
	}
}}