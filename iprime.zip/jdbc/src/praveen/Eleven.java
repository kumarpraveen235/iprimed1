package praveen;
import java.sql.*;

public class Eleven {
public static void main(String[] args) {
	try {
    Connection conn=ConnectionUntil.getConnection();
	System.out.println("connected");
	PreparedStatement  pst=conn.prepareStatement("select * from book");
	ResultSet r=pst.executeQuery();
	ResultSetMetaData  rm=r.getMetaData();
	for(int  i=1;i<=rm.getColumnCount();i++)
	{
		System.out.print(rm.getColumnName(i)+"  ");
	}
	System.out.println();
	while(r.next())
	{
		for(int  i=1;i<=rm.getColumnCount();i++)
		{
			System.out.print(r.getString(i)+"  ");
		}
		System.out.println();
	}
	}
	catch (Exception e) {
		// TODO: handle exception
	}
}}
