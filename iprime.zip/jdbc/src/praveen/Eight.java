package praveen;
import java.sql.*;
public class Eight {
public static void main(String[] args) {
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection  conn=DriverManager.getConnection
			("jdbc:mysql://localhost:3306/iprimed", "root", "123456");

System.out.println("connected");
String  s="insert into book values(?,?,?)";

PreparedStatement pst=conn.prepareStatement(s);
pst.setInt(1, 10);
pst.setString(2, "Angular");
pst.setDouble(3, 1767.99);
System.out.println(pst.executeUpdate()+"  row inserted!");
System.out.println("book   table  data");
PreparedStatement pst1=conn.prepareStatement("select * from book");
ResultSet   r=pst1.executeQuery();
while(r.next())
{
	System.out.println(r.getString(1)+"  "+r.getString(2)+"  "+r.getString(3));
}
	}
	catch (Exception e) {
		// TODO: handle exception
	}
}}
