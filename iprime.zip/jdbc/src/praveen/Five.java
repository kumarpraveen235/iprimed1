package praveen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
public class Five {
public static void main(String[] args) {
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection  conn=DriverManager.getConnection
			("jdbc:mysql://localhost:3306/iprimed", "root", "123456");

System.out.println("connected");
Statement  s=conn.createStatement
(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
String str="select * from book";
ResultSet  r=s.executeQuery(str);
//r.afterLast();// placess the result set  cursor after last row
r.absolute(2);//placess  the  resultset cursor at  2nd row
System.out.println("row  no   "+r.getRow());
r.relative(-2);//  places the  cursor  at  top of the  row
while(r.next())
{
	System.out.println(r.getString(1)+"  "+r.getString(2)+"   "+r.getString(3));
}
	}
	catch (Exception e) {
		// TODO: handle exception
	}
}}