package praveen;
import java.sql.*;
public class ConnectionUntil {
	
	private  static  Connection conn=null;
	
	public  static  Connection  getConnection() 
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		conn=DriverManager.getConnection
				("jdbc:mysql://localhost:3306/iprimed", "root","123456");
	
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return  conn;
	}

}
