package praveen;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
public class Six {
public static void main(String[] args) {
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection  conn=DriverManager.getConnection
			("jdbc:mysql://localhost:3306/iprimed", "root", "123456");

System.out.println("connected");
Statement  s=conn.createStatement
(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
String str="select id, name, price from book";
    
ResultSet  r=s.executeQuery(str);
r.absolute(3);//   result set  cursor at 3nd row
//r.updateString(2, "unix");
//r.updateRow();
r.deleteRow();// deletes   3rd row
r.beforeFirst();//places the  resultset pointer  at  top of row
while(r.next())
	
{
	System.out.println(r.getString(1)+"  "+r.getString(2)+"   "+r.getString(3));
}
	}
	catch (Exception e) {
		// TODO: handle exception
	}
}}