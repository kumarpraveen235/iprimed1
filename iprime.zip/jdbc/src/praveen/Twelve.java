package praveen;
import java.sql.*;
public class Twelve {
	public static void main(String[] args) {
		 try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection  conn=DriverManager.getConnection
						("jdbc:mysql://localhost:3306/iprimed", "root", "123456");
				System.out.println("connected");
				PreparedStatement  p=conn.prepareStatement
						("select id,name,price from book",
	ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet r=p.executeQuery();
				r.absolute(12);
				r.updateString(2, "typescript");
				r.updateDouble(3, 999.99);
				r.updateRow();
				r.beforeFirst();
				while(r.next())
				{
System.out.println(r.getString(1)+"   "+r.getString(2)+"   "+r.getString(3));					
				}
	}
		 catch(Exception e)
		 {}
		 

}
}
