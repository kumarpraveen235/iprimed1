package praveen;
import java.io.*;
public class Four {
public static void main(String[] args) throws IOException{
	PrintWriter  pw=new PrintWriter(System.out, true);
	pw.println("ajay");
	pw.println('a');;
	pw.println(7586.77);
	pw.println(689);
}
}
