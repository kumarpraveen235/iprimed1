package praveen;
import java.io.*;
public class One {
public static void main(String[] args)  throws IOException{
	String  s="this is  java FSD training";
	FileWriter  f=new FileWriter("a.txt");
	f.write(s);
f.flush();
	System.out.println("Written");
	int  i=0;
	FileReader  fr=new FileReader("a.txt");
	while((i=fr.read())!=-1)
	{
		System.out.print((char)i);
	}
}
}
