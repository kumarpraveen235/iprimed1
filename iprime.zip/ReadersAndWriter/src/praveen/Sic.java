package praveen;
import java.io.*;
public class Sic {
public static void main(String[] args) throws IOException {
	RandomAccessFile  r=new RandomAccessFile("p1.txt", "rw");
	/*
	 * r.writeChar('s'); r.writeInt(222); r.writeDouble(7576.757);
	 * 
	 * System.out.println("written"); r.seek(0); System.out.println(r.readChar());
	 * System.out.println(r.readInt()); System.out.println(r.readDouble());
	 * r.seek(2); System.out.println(r.readInt()); r.seek(4);
	 */
	   r.seek(4);
	String ss="hi hello how are you";
	byte[] b=ss.getBytes();
	r.write(b);
	System.out.println("done");
	r.seek(8);
	int i=0;
	while((i=r.read())!=-1)
	{
		System.out.print((char)i);
	}
	System.out.println();
	r.seek(r.length());
	System.out.println(r.getFilePointer());
	r.writeBoolean(false);
	r.seek(24);
	System.out.println(r.readBoolean());
}
}
