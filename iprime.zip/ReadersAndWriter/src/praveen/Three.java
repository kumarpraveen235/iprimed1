package praveen;
import java.io.*;
public class Three {
public static void main(String[] args) throws Exception {
	PipedWriter  po=new PipedWriter();
	PipedReader  pi=new PipedReader();
	pi.connect(po);
	Thread t1=new Thread() {
		@Override
		public  void run()
		{
			for(int i=1;i<6;i++)
			{
				try {
					Thread.sleep(1000);
					po.write(i);
				}
				catch (Exception e) {
					System.out.println("Handeled  "+e);
				}
			}
		}
	};
	Thread t2=new Thread() {
		@Override
		public  void run()
		{
			for(int i=1;i<6;i++)
			{
				try {
					Thread.sleep(1000);
					System.out.println(pi.read());
				}
				catch (Exception e) {
					System.out.println("Handeled  "+e);
				}
			}
		}
	};
	t1.start();t2.start();
}
}
