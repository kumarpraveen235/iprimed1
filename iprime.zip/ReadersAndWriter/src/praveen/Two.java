package praveen;

import java.io.CharArrayWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Two  {
public static void main(String[] args) throws IOException {
	String  s="written  to  more than 2 files";
	FileWriter  f1=new FileWriter("x.txt");
	FileWriter  f2=new FileWriter("y.txt");
	FileWriter  f3=new FileWriter("z.txt");
	CharArrayWriter  c=new CharArrayWriter();
	c.write(s);
	c.writeTo(f1);c.flush();f1.close();
	c.writeTo(f2);c.flush();f2.close();
	c.writeTo(f3);c.flush();f3.close();
	System.out.println("written");
}
}
