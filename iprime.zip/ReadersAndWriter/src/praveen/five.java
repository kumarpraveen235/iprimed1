package praveen;
import java.io.*;
public class five {
public static void main(String[] args) throws IOException {
	System.out.println("enter  input");
	InputStreamReader  i=new InputStreamReader(System.in);
	BufferedReader br=new BufferedReader(i);
	int  k=Integer.parseInt(br.readLine());
	System.out.println(k);
	String str=br.readLine();
	System.out.println(str);
}
}
