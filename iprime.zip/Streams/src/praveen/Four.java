package praveen;
import java.util.*;
import java.util.stream.*;
class Product
{
	int id;
	String name;
	double price;
	public Product(int id, String name, double price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
}
public class Four {
public static void main(String[] args) {
	ArrayList<Product> a=new ArrayList<Product>();
	a.add(new Product(1, "laptop",50000.88));
	a.add(new Product(2, "mouse",1000.75));
	a.add(new Product(3, "keyboard",4000.20));
	a.add(new Product(4, "iphone",45000.45));
	a.add(new Product(5, "mobile",20000.80));
	List<Product>  l=a.stream().filter(h->h.price>10000).collect(Collectors.toList());
for(Product  pp:l)
{
	System.out.println(pp);
}
      //Optional<Product> o=  a.stream().max((i,j)->(i.price>j.price?1:-1));
      //System.out.println(o.get().price);
      Optional<Product> o1=  a.stream().min((i,j)->(i.price>j.price?1:-1));
      System.out.println(o1.get().price);
}
}
