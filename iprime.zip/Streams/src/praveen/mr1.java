package praveen;
import  java.util.*;
import java.util.stream.*;
public class mr1 {
public static void main(String[] args) {
	ArrayList<Integer> al=new ArrayList<Integer>();
	al.add(24);	al.add(20);	al.add(22);	al.add(12);
	al.forEach(System.out::println);
	//  forEach takes parameter as consumer
	// which  takes one argument and returns nothing
	//  println() suites  for  this  as it also  takes parameter and returns nothing
	// i can represent println as method reference
	System.out.println();
	ArrayList<String> al1=new ArrayList<String>();
	al1.add("ajay");al1.add("raj");al1.add("amir");al1.add("amar");al1.add("akshay");
	al1.add("rohit");al1.add("ravi");al1.add("deepa");al1.add("asha");
	al1.add("anil");
	al1.stream().filter(g->g.startsWith("a")).map(String::toUpperCase)
	.forEach(System.out::println);
}
}
