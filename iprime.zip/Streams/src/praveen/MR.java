package praveen;
@FunctionalInterface
interface  i1
{
	    void  m(int i);
}
public class MR {
      void  n(int j)
     {
    	 System.out.println(j);
     }
     
     public static void main(String[] args) {
		i1  i=new MR()::n;//  instance  method reference
		i.m(100);
	}
}
