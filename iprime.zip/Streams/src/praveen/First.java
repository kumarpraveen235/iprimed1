package praveen;
import  java.util.*;
import java.util.stream.*;
import java.util.stream.Collectors;

public class First {
	public static void main(String[] args) {
		/*
		 * Stream<String> s=Stream.of("kumar","aman","rakesh","vivek");
		 * s.forEach((str)->System.out.println(str));
		 */
		
		/*
		 * ArrayList<Integer> a=new ArrayList<Integer>();
		 * a.add(10);a.add(15);a.add(13);a.add(12);a.add(11);
		 * a.forEach((n)->System.out.println(n));
		 */
		
		/*
		 * List<String> l=Arrays.asList("amar", "lokesh", "suman", "neha", "deepa");
		 * l.forEach(h->System.out.println(h));
		 */
		
		ArrayList<Integer> a=new ArrayList<Integer>();
		  a.add(12);a.add(12);a.add(12);a.add(12);a.add(11);
		  a.add(12);a.add(12);a.add(32);a.add(19);a.add(81);
			/*
			 * Stream<Integer> st=a.stream(); Stream<Integer> st1=st.filter(i->i%2!=0);
			 * st1.forEach(h->System.out.println(h));
			 */
	//	  a.stream().filter(i->i%2!=0).forEach(g->System.out.println(g));
		//  long  tot=a.stream().count();
		 // System.out.println("total elements  "+tot);
	//	a.stream().sorted().forEach(g->System.out.println(g));
		//  a.stream().distinct().forEach(k->System.out.println(k));
		  
		  a.stream().map(p->p*10).forEach(g->System.out.println(g));
	}

}
