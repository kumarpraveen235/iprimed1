package praveen;
import java.util.*;
import java.util.stream.*;
public class Second {
public static void main(String[] args) {
	/*
	 * List<String> names=Arrays.asList("amar","arjun", "ankint","mohan", "raj",
	 * "pavan", "avinash", "akash", "ajit", "ajay", "Kiran");
	 * names.stream().filter(s->s.startsWith("a")).map(u->u.toUpperCase()).sorted()
	 * .forEach(f->System.out.println(f));
	 */
	/*
	 * Stream<Integer> s=Stream.of(22,29,31,44,44,12,19,18,54,44,76,26);
	 * Set<Integer> i=s.filter(n->n>30).collect(Collectors.toSet()); for(Integer
	 * ii:i) { System.out.println(ii); }
	 */
	/*
	 * Stream<String> n=Stream.of("a","ab","abc","abcd","bc","ba","bd");
	 * System.out.println(n.allMatch(z->z.startsWith("a")));
	 */
	/*
	 * Stream<String> n=Stream.of("a","ab","abc","abcd","bc","ba","bd");
	 * Optional<String> o=n.filter(s->s.startsWith("b")).findFirst();
	 * System.out.println(o.get());
	 */
	//ArrayList<Integer> al=new ArrayList<Integer>();
//	al.add(1);al.add(91);al.add(15);al.add(-1);al.add(11);al.add(2);
	//Optional<Integer> o=al.stream().min((a,b)->a-b);
//	Optional<Integer> o=al.stream().max((a,b)->a-b);
//	System.out.println(o.get());
	// Optional<Integer> o=al.stream().reduce((i,j)->i+j);
//	 System.out.println(o.get());
	
	List<String> names=Arrays.asList("amar","arjun", "ankint","mohan", "raj",
			 "pavan", "avinash", "akash", "ajit", "ajay", "Kiran");
	names.stream().filter(x->x.startsWith("a")).sorted().limit(5).forEach
	(n->System.out.println(n));
	
}
}
