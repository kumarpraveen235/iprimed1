package praveen;
import  java.util.*;
class Student
{
	int id;
	String  name;int age;

	public Student(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + "]";
	}
	
}
public class Third {
public static void main(String[] args) {
	ArrayList<Student>  al=new ArrayList<Student>();
	al.add(new Student(1, "Vinod", 22));
	al.add(new Student(2, "virat", 25));
	al.add(new Student(3, "Varsha", 21));
	al.add(new Student(4, "Varun", 28));
	al.add(new Student(5, "vikas", 20));
	Collections.sort(al, (n1,n2)->{
		return n1.name.compareTo(n2.name);
	});
	for(Student s:al)
	{
		System.out.println(s);
	}
	System.out.println();
	Collections.sort(al, (a1,a2)->{
		if(a1.age==a2.age) return 0;
		if(a1.age>a2.age) return 1;
		else return -1;
		
	});
	for(Student s:al)
	{
		System.out.println(s);
	}
}
}
