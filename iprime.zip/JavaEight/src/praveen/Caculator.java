package praveen;
@FunctionalInterface
interface  cal
{
	     void   add(int a, int b);
}
public class Caculator {
public static void main(String[] args) {
	cal c=(i, j)->System.out.println(i+j);
	
	c.add(4, 4);
}
     
}
