package praveen;
@FunctionalInterface
interface  i1
{
	     void m();
	     default   int k()
	     {
	    	 return 10;
	     }
	     default  void m1()
	     {
	    	 System.out.println("welcome");
	     }
}
public class One implements i1{   // normal class

	@Override
	public void m() {
		System.out.println("i am  functional interface method");
	}
 public static void main(String[] args) {
	   new One().m();
	  System.out.println(new One().k());
	  new One().m1();
}
}
