package praveen;
@FunctionalInterface
interface inter
{
	   String   get(String s);
}
public class Four {
public static void main(String[] args) {
	/*
	 * inter i=a->{ return a; };
	 */
	inter  i=a->"hi  "+a;
	
	System.out.println(i.get("praveen"));
}
}
