package praveen;

public class Six {
public static void main(String[] args){
	Runnable  r=()->{
		for(int i=1;i<6;i++)
		{
			try {
			Thread.sleep(1000);
			System.out.println(i);
		}
			catch(InterruptedException e)
			{
				System.out.println("sleep interrupted  "+e);
			}
		}
	};
	    Thread t=new Thread(r);
	    t.start();
}
}
