package praveen;

import java.util.Optional;

public class OP {
public static void main(String[] args) {
	String[] s=new String[19];
	s[5]="sanjay";
	         Optional<String>  o=      Optional.ofNullable(s[5]);
	         if(o.isPresent())
	         {
	        	 String  ss=s[5].toUpperCase();
	        	 System.out.println(ss);
	         }
	         else
	         {
	        	 System.out.println("it's value  not present");
	         }
}
}
