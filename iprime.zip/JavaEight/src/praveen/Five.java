package praveen;
@FunctionalInterface
interface inter10{
	  int  mul(int a, int b, int c);
}
public class Five {
public static void main(String[] args) {
	inter10 in=(i,j,k)->{
		 int   p=100;
		 return i*j*k*p;
	};
	System.out.println("Prod   "+in.mul(1, 2, 3));
}
}
