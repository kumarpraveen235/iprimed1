package praveen;
@FunctionalInterface
interface  i2
{
	     void m();
}
public class Two {
	public static void main(String[] args) {
		i2  i=new i2()  // anonymous inner class
				
				{

					@Override
					public void m() {
						System.out.println("i am functional interface  method");
					}
			
				};
				i.m();
	}

}
