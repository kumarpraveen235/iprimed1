package praveen;
class Student{}
public class Four {
public  static  void m()
{
	Student s1=new Student();
	Student s2=new Student();  
}
public static void main(String[] args) {
	        m();
}
}
//in the  above progam      2 objects are   eligible  for gc
//because  2  objects are  created  in the method m()  when  the
// invocation  of the  m() metgod is over   they are  elgible for  gc