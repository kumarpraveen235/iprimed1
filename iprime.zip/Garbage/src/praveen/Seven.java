package praveen;

public class Seven {
   public static void main(String[] args) {
	Runtime   r=Runtime.getRuntime();
	System.out.println(r.totalMemory());
	System.out.println(r.freeMemory());
	for(int i=1;i<10000000;i++)
	{
		new Seven();// 10000000 anonymous objects created eligible for gc
	}
     System.out.println(r.freeMemory());
     r.gc();//   garbage collection
     System.out.println(r.freeMemory());
}
}
