package praveen;

public class Three {
    void m()
    {
    	System.out.println("Hi");
    }
    public static void main(String[] args) {
		new Three().m();
		
		new Three();
		new Three();
		//totally  3 object eligible  for gc
	}
}
