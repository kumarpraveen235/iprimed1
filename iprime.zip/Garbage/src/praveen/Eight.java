package praveen;

public class Eight {
	@Override
	
   protected void finalize()
   {
	   System.out.println("finalize called");
   }
   public static void main(String[] args) {
		/*
		 * Eight e=new Eight(); Eight e1=new Eight(); Eight e2=new Eight(); e=null;// e
		 * is eligible for GC new Eight(); e1=e2;// e1 is eligible for gc
		 */
	   String s1=new String("welcome");
	   s1=null;
	   System.gc();
	   //  in the   above program   it will call  String class's   finalize()
	   // method. But String class's  finalize() method
	   // has  empty implementation  so   u will not see any thing the o/p
}
}
