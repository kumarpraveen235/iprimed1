package praveen;
class Student3{}
public class Six {
	static Student3  s1;
public  static  void m()
{
	s1=new Student3();
	Student3 s2=new Student3();  
	
}
public static void main(String[] args) {
	    m();
	    
}
}
//in the  above progam      1 objects are   eligible  for gc
// which  s2 s1 is  static   instance  variable so  it not  eligible
//for  gc as  it is not declared in m() method
