package praveen;

public class Two {

   void m()
   {
	   System.out.println("Hi");
   }
   public static void main(String[] args) {
Two  t=new Two();
Two t1=new Two();
System.out.println(t+"\t"+t1);
t=t1;//  t is   eligible for gc
System.out.println(t+"\t"+t1);

}
}