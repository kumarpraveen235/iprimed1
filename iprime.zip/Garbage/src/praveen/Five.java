package praveen;
class Student1{}
public class Five {
public  static  Student1 m()
{
	Student1 s1=new Student1();
	Student1 s2=new Student1();  
	return  s1;
}
public static void main(String[] args) {
	       Student1 s3=m();
	    
}
}
//in the  above progam      1 objects are   eligible  for gc
//because  2  objects are  created  in the method m()  when  the
// invocation  of the  m() metgod is over   m()  still points  to 
//s1 so only   s2  is eligible  for gc
