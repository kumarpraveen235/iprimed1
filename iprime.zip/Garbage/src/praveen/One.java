package praveen;

public class One {
   void m()
   {
	   System.out.println("Hi");
   }
   public static void main(String[] args) {
One  o=new One();
o=null;///eligible  for gc
   o.m();
}
}
