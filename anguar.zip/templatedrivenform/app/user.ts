export    class User
{
       name:string="";
       contact:string="";
       city:string="";
}