import { AfterViewInit, Component, ViewChild } from '@angular/core';
import {User} from './user';
@Component({
  selector: 'app-root1',
 templateUrl:'./app.component.html',
 styleUrls:['./app.component.css']
})
export class AppComponent  {
  userList:User[]=[];
 addUser(frm:any){
  // console.log(frm.value);
  var u:User;
  u=frm.value;
  this.userList.push(u);
  console.log(this.userList);
 }
    
}
