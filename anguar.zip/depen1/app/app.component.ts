import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { Product}  from './product';
import { ProductService } from './product.service';
@Component({
  selector: 'app-root1',
 templateUrl:'./app.component.html',
 styleUrls:['./app.component.css']
})
export class AppComponent  {
  title:string="welcome  to component  communication";
      products:Product[]=[];
      constructor(private ps:ProductService)  //  DI
      {}
      get()
      {
        this.products=this.ps.showProducts();
      }

}
