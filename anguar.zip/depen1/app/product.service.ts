import { Injectable } from "@angular/core";
import { Product } from "./product";
@Injectable()
export class ProductService
{
    public   showProducts()
    {
        let   products : Product[];
        products=[
            new Product(1, "laptop",75868),
            new Product(2, "mobile",14868),
            new Product(3, "iphone",55868),
            new Product(4, "pendrive",758),
            new Product(5, "mouse",888),
        ]
        return   products;
    }
}