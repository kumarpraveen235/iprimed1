import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { OneComponent } from './one.component';
import { TwoComponent } from './two.component';
import { RouterModule } from '@angular/router';
import { routes } from './app.route';
@NgModule({
  declarations: [
    AppComponent, OneComponent, TwoComponent

    
  ],
  imports: [
    BrowserModule, RouterModule.forRoot(routes)

  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
