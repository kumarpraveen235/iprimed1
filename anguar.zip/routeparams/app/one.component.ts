import { Component } from "@angular/core";

@Component({
    selector:'component-one',
    template:`<h1>Component One</h1>`
})
export  class  OneComponent{}