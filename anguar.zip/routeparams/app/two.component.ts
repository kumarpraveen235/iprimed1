import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

@Component({
    selector:'component-two',
    template:`<h1>Component Two
    with  route parameter <b><code>ID: {{id}}</code></b></h1>`
})
export  class  TwoComponent implements OnInit{
    id:number=0;
    paramssubsription:any;
    constructor(private route:ActivatedRoute,
       ){}
    ngOnInit(): void {
     this.paramssubsription=this.
        route.params.subscribe(params=>{
            this.id=+params['id'];
        });
    }
  

}