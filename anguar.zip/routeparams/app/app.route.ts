import {Routes} from '@angular/router'
import { OneComponent } from './one.component';
import { TwoComponent } from './two.component';
export  const routes:Routes=[
    {path: '', redirectTo:'one.component', pathMatch:'full'},
    {path:'one', component:OneComponent},
    {path:'two/:id', component:TwoComponent}
]