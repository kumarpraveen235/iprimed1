package com.ey.training.fsd.controller;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ey.training.fsd.model.User;
import com.ey.training.fsd.service.UserService;
@CrossOrigin
(origins = "http://localhost:3000")
@RestController
public class UserController {
@Autowired
UserService  us;
@GetMapping("/list")
public   List<User>   get()
{
	return us.get();
}
@PostMapping("/save")
public  User   addUser(@RequestBody User  u)
{
	return    us.addUser(u);
}
@GetMapping("/byId/{id}")
public User  getById(@PathVariable("id") int id)
{
	  return  us.getById(id);
}
@PutMapping("/update/{id}")
public  User   update(@PathVariable("id") int id, @RequestBody User u)
{
	    return    us.update(id, u);
	    
}
@DeleteMapping("/delete/{id}")
public void  remove(@PathVariable("id") int id)
{
	     us.delete(id);
}
}
