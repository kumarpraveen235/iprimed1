package com.ey.training.fsd.service;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ey.training.fsd.exception.UserNotFoundException;
import com.ey.training.fsd.model.User;
import com.ey.training.fsd.repository.UserRepository;

@Service
public class UserService {
@Autowired
UserRepository  ur;
@Transactional
public  User   addUser(User  u)
{
	     return ur.save(u);
}
@Transactional
   public  List<User>  get()
{
	     return   ur.findAll();
}
@Transactional
public   User   getById(int id)
{
	User u=ur.findById(id).orElseThrow
			 (()->new UserNotFoundException("id  "+id));
	  return u;
}
@Transactional
public   User   update(int id, User u1)
{
	 User u=ur.findById(id).orElseThrow
			 (()->new UserNotFoundException("id  "+id));
	  	  u.setName(u1.getName());
	  	  u.setCity(u1.getCity());
	  	
	  return ur.save(u);
	  
}
@Transactional
public  void delete(int id)
{
	User u=ur.findById(id).orElseThrow
			 (()->new UserNotFoundException("id  "+id));
	   ur.deleteById(id);
}
}
