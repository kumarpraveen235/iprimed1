package com.ey.training.fsd.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ey.training.fsd.model.User;
@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	

}
