import {Directive, ElementRef, HostListener, Input} from '@angular/core';
@Directive({
    selector:'[customhover]'
})
export    class MyDirective
{
    @Input()   hovercolor:string="";
    constructor(private e:ElementRef)
    {}
    public   hiliteColor(color:string)
    {
     this.e.nativeElement.style.backgroundColor=color;
    }
    @HostListener('mouseenter') onMouseEnter()
    {
     this.hiliteColor(this.hovercolor);
    }
    @HostListener('mouseleave') onMouseLeave()
    {
     this.hiliteColor('magenta');
    }
}