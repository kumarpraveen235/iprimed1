import { HttpClient } from "@angular/common/http";
import { employee } from "./employee";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
@Injectable()
export class EmpService
{
    url="http://localhost:3000/";
    constructor(private hc:HttpClient){}
    
    getEmpById(id:number):Observable<employee>
    {
       console.log('get emp  '+this.url+'employee/'+id);
       return this.hc.get<employee>(this.url+'employee/'+id);
    }
    
}