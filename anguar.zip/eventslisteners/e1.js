 function  color(clr)
{
    document.getElementById("t").style.backgroundColor=clr;
} 

function     logic(clr1){
document.getElementById("t1").style.backgroundColor=clr1;

}
function  up()
{
    var v=document.getElementById("t1");
    alert("welcome  "+v.value);
v.value=v.value.toUpperCase();
}