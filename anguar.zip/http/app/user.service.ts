import { Injectable } from "@angular/core";
import {HttpClient} from '@angular/common/http';
@Injectable()
export  class  UserService
{
       private url="http://localhost:3000/employee";

       constructor(private  hc:HttpClient){}

       getUsers()
       {
        return this.hc.get(this.url);
       }
}