import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { UserService } from './user.service';
import { FormControl,FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root1',
 templateUrl:'./app.component.html',
 styleUrls:['./app.component.css']
})
export class AppComponent implements OnInit {
    title:string="angular 12 httpclientmodule example";
    users:any;
    constructor(private us:UserService){}
    ngOnInit(): void {
      this.us.getUsers().subscribe(r=>{
        this.users=r;
      })
    }
}