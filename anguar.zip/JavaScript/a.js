var a=20.0;
var b=568;
var c=a+b;
document.write("<h1>Sum  "+c+"<br/>");
var  z;   alert(z);
var p=10;
alert(p++);
alert(++p);
document.write(10|10);
var s="10";
var s1=10;
document.write("<br>"+(s===s1)+"<br/>");
document.write(s==s1)
var  f=true ; var f1=false;
document.write("<h1>"+(f||f1));