/* var   a=prompt("eneter  1st  no");
var b=prompt("enter 2nd no");
c=Number.parseInt(a)+Number.parseInt(b);
document.write("<h1>Sum "+c); */
var n=prompt("enter   limit ");
/* while(n>0)
{
    document.write("<h1>"+n);
     n--;
     
} */
/* if(n==10)
{
       alert("hi");
}
else{
    alert("bye!");
} *//* 
switch(n)
{
       case "mon":  document.write("monday");break;
       case "tue":  document.write("tuesday");break;
       case "wed":  document.write("wednesday");break;
       case "thu":  document.write("thursday");break;
       case "fri":  document.write("friday");break;
      default: document.write("weekend");break;
    } */
    for(var i=1; i<=n;i++)
    {
        if((i%2)==0) continue;
        document.write("<h1>"+i);
    }