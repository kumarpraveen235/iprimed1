import { AfterViewInit, Component, ViewChild } from '@angular/core';

import { FormControl,FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root1',
 templateUrl:'./app.component.html',
 styleUrls:['./app.component.css']
})
export class AppComponent  {
      title:string="angular 12 routing!!"
       parentdata:string="starting......";
       constructor(){
        setTimeout(()=>{
          this.parentdata="final data.......";
        }, 5000);
       }
}