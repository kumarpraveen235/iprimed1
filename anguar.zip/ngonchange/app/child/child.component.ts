import  {Component, Input, OnChanges} from '@angular/core'
@Component({
    selector:'app-child',
    template:`<h2>Child component<h2>
   <h2>ticks : {{lifecycleticks}}</h2>
   <h2>data: {{data}}</h2>
    `
})
export class ChildComponent implements OnChanges{
    @Input()  data:string="";
    lifecycleticks:number=0;
    ngOnChanges(){
        console.log("inside   ngonchanges")
        this.lifecycleticks++;
        
    }
}