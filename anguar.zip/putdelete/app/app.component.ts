import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';

import { FormControl,FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root1',
 templateUrl:'./app.component.html',
 styleUrls:['./app.component.css']
})
export class AppComponent {
  title:string="PUT EXAMPLE";
  constructor(private  hc:HttpClient){
    hc.put("http://localhost:3000/employee/3",{
      "name":"ahmed",
      "age":27,
      "city":"jaipur"
    }).subscribe(data=>{
      console.log("PUT request is  successfull", data);
    });
  }
    }

/*   delete   */
/*

import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';

import { FormControl,FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root1',
 templateUrl:'./app.component.html',
 styleUrls:['./app.component.css']
})
export class AppComponent {
  title:string="PUT EXAMPLE";
  constructor(private  hc:HttpClient){
    hc.delete("http://localhost:3000/employee/5").subscribe(data=>{
      console.log("DELETE request is  successfull", data);
    });
  }
    }
   */   