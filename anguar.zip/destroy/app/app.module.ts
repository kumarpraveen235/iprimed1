import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { DestroyListener } from './destroy.listener';
@NgModule({
  declarations: [
    AppComponent, DestroyListener
    
  ],
  imports: [
    BrowserModule

  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
