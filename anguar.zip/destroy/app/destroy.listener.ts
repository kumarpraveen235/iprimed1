import { Directive, Component, OnDestroy } from "@angular/core";
@Directive({
    selector:'[appdestroylistener]'
})
export class DestroyListener implements   OnDestroy
{
    ngOnDestroy(): void {
        console.log("good bye  to component");
    }
}







