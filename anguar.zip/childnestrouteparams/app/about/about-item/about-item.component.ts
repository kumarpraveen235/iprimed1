import { Component,  OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
@Component({
    selector:'app-about-item',
    templateUrl:'./about-item.component.html'
})
export class AboutItemCompnent implements OnInit{
    id:number=0;
    paramSub:any;
    constructor(private ar:ActivatedRoute){}
    ngOnInit(): void {
        this.paramSub=this.ar.params.subscribe
        (params=>{
            this.id=+params['id'];
        });
    }

}