import { Component } from "@angular/core";
@Component({
    selector:'app-about-home',
    templateUrl:'./about-home.component.html'
})
export class AboutHomeCompnent{}