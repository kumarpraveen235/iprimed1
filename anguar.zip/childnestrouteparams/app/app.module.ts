import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HomeCompnent } from './home/home.component';
import { AboutCompnent } from './about/about.component';
import { RouterModule } from '@angular/router';
import { routes } from './app.route';
import { AboutHomeCompnent } from './about/about-home/about-home.component';
import { AboutItemCompnent } from './about/about-item/about-item.component';
@NgModule({
  declarations: [
    AppComponent, HomeCompnent, AboutCompnent,AboutHomeCompnent
,AboutItemCompnent
    
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(routes)

  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
