import {Routes} from '@angular/router'
import { AboutHomeCompnent } from './about/about-home/about-home.component'
import { AboutItemCompnent } from './about/about-item/about-item.component'
import { AboutCompnent } from './about/about.component'
import { HomeCompnent } from './home/home.component'
export const  routes:Routes=[
    {path:'', component:HomeCompnent},
    {path:'about', component:AboutCompnent,children :[
        {path: '', component:AboutHomeCompnent},
        {path: 'item/:id', component:AboutItemCompnent}
    ]}
]