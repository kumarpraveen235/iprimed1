import  {Injectable} from '@angular/core'
@Injectable()
export  class EmployeeService
{
    public  emprecord=[
        {name:"sunny", city:"goa", id:1},
        {name:"vijay", city:"pune", id:1},
        {name:"sumit", city:"noida", id:3},
        {name:"vishwas", city:"jammu", id:4},
        {name:"sonu", city:"delhi", id:5}
    ];
    public        getEmpById(id:number):any{
        let e:any;
        for(let i=0;i<this.emprecord.length;i++)
        {
            if(id===this.emprecord[i].id)
            {
                e=this.emprecord[i];
                break;
            }
        }
        return e;
    }
}