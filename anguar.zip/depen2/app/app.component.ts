import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { EmployeeService } from './employee.service';
@Component({
  selector: 'app-root1',
 templateUrl:'./app.component.html',
 styleUrls:['./app.component.css']
})
export class AppComponent  {
  title:string="welcome  to component  communication";
     public    eobj:any;
     public eid:number=0;
     constructor(private es:EmployeeService){}
     public  getById():void{
       this.eobj=this.es.getEmpById(this.eid);
     }
}
