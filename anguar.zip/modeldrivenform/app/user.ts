export    class User
{
       name:string="";
       contact:string="";
       email:string="";
}