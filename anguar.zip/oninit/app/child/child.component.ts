import  {Component, Input, OnChanges, OnInit} from '@angular/core'
@Component({
    selector:'app-child',
    template:`<h2>Child component<h2>
   <h2>ticks : {{lifecycleticks}}</h2>
   <h2>data: {{data}}</h2>
    `
})
export class ChildComponent implements OnInit{
    @Input()  data:string="";
    lifecycleticks:number=0;
    ngOnInit(){
        console.log("inside   ngonchanges")
        this.lifecycleticks++;
        
    }
}