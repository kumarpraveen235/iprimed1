export   class Customer{
        id:number=0;
        name:string="";
        address:string="";
        city:string="";
        state:string="";
        country:string="";
        
}