import { Component, OnInit } from '@angular/core';
import { Customer } from './customer';

@Component({
  selector: 'app-customer',//   looked nested   in app.component.html
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent  {
   
  cus:Customer[]=[
    {id:1,name:"sanjay",address:"mgroad", city:"panjim",
  state:"goa", country:"india"},
  {id:2,name:"john",address:"street 22", city:"sydney",
  state:"sydney", country:"australia"},
  {id:3,name:"boris",address:"street 100", city:"london",
  state:"london", country:"uk"},
  {id:4,name:"wasim",address:"jpnagar", city:"bangalore",
  state:"karnataka", country:"india"},
  {id:5,name:"abdul",address:"mcgrath road", city:"bangalore",
  state:"karnataka", country:"india"}
  
  

  

  ]

}
