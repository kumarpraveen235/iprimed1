import { Component } from '@angular/core';

@Component({
  selector: 'app-root1',
 templateUrl:'./app.component.html',
 styleUrls:['./app.component.css']
})
export class AppComponent {
      title:string="welcome";
}
