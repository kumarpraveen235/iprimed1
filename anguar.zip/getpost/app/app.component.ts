import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';

import { FormControl,FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmpService } from './emp.service';
import { employee } from './employee';
@Component({
  selector: 'app-root1',
 templateUrl:'./app.component.html',
 styleUrls:['./app.component.css']
})
export class AppComponent implements OnInit  {
    title:string='http GET POST example';
    emps:employee[]=[];
    emp=new employee();
    constructor(private    apiservice:EmpService)
    {

    }
    ngOnInit(): void {
         this.refreshEmp();
    }
    refreshEmp(){
      this.apiservice.getEmp().subscribe
      (data=>{
        console.log(data);
        this.emps=data;
      })
    }
   addEmp()
   {
      this.apiservice.addEmp(this.emp).subscribe
      (data=>{
        console.log(data);
        this.refreshEmp();
      })
   }
}