export class employee{
    public  id:number=0;
    public name:string="";
    public age:number=0;
    public city:string="";

  
}