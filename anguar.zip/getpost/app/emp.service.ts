import { HttpClient } from "@angular/common/http";
import { employee } from "./employee";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
@Injectable()
export class EmpService
{
    url="http://localhost:3000/";
    constructor(private hc:HttpClient){}
    
    getEmp():Observable<employee[]>
    {
       console.log('get emp  '+this.url+'employee');
       return this.hc.get<employee[]>(this.url+'employee');
    }
    addEmp(e:employee):Observable<any>
    {
        const headers={ 'content-type':'application/json'}
        const body=JSON.stringify(e);
        console.log(body);
        return this.hc.post
        (this.url+'employee',body,{'headers':headers})
    }
}