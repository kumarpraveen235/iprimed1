import { Component } from "@angular/core";
@Component({
    template:`<div style=
    "width:550px;height:550px;background-color:cyan;">
    <h1>This is Angular page</h1></div>`
})
export class AngularComponent{}