import { Component } from "@angular/core";
@Component({
    template:`<div style=
    "width:350px;height:350px;background-color:blue;">
    <h1>This is  spring boot page</h1></div>`
})
export class SpringBootComponent{}