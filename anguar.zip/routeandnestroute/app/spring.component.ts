import { Component } from "@angular/core";
@Component({
    template:`<div style=
    "width:350px;height:350px;background-color:green;">
    <h1>This is  spring page</h1></div>`
})
export class SpringComponent{}