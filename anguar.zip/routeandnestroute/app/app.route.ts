import {Routes} from '@angular/router';
import { HomeComponent } from './home.component';
import { JavaComponent } from './java.component';
import { AngularComponent } from './angular.component';
import { SpringComponent } from './spring.component';
import { SpringBootComponent } from './springbootcomponent';
export const routes:Routes=[
    {path:'', component:HomeComponent},
    {path:'java', component:JavaComponent, children:
[{path:'spring', component:SpringComponent},
{path:'boot', component:SpringBootComponent}]},
    {path:'angular', component:AngularComponent}
]