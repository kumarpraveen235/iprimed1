import { Component } from "@angular/core";
@Component({
    template:`<div style=
    "width:550px;height:550px;background-color:yellow;">
    <h1>This is Java page</h1>
   <h2> <a [routerLink]="['spring']">spring</a></h2>
   <h2> <a [routerLink]="['boot']">springboot</a></h2>
   <router-outlet></router-outlet>
    </div>`
})
export class JavaComponent{}