import { Component } from "@angular/core";
@Component({
    template:`<div style=
    "width:550px;height:550px;background-color:magenta;">
    <h1>This is Home page</h1></div>`
})
export class HomeComponent{}