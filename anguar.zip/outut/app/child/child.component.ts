import { Component, OnInit , Input, Output, EventEmitter} from '@angular/core';


@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent {
   message:string=
   "sending message from  child to parent through output";
   @Output()  messageevent=new EventEmitter<string>();
   sendmessage()
   {
     this.messageevent.emit(this.message);
   }

}
