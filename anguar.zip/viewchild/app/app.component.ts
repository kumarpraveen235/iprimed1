import { AfterViewInit, Component, ViewChild } from '@angular/core';
import  {ChildComponent} from './child/child.component';
@Component({
  selector: 'app-root1',
 templateUrl:'./app.component.html',
 styleUrls:['./app.component.css']
})
export class AppComponent implements  AfterViewInit {
  title:string="welcome  to component  communication";
    @ViewChild(ChildComponent,{static:true})  child:any="";
    message:any="";
    ngAfterViewInit(): void {
      this.message=this.child.message;
    }
}
