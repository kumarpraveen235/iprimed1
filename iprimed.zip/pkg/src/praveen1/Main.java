package praveen1;

public class Main extends praveen.HelloWorld {
public static void main(String[] args) {
	Main h=new Main();
	System.out.println(h.id);
	h.m();
	System.out.println(h.b);
	h.g();
}
}
