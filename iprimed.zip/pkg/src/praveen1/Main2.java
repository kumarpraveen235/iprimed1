package praveen1;
class   Main2 extends  String
{}