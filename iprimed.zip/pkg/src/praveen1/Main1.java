package praveen1;
import  praveen.*;
public class Main1 implements my {

	@Override
	public double sum(float a, float b) {
		return a+b;
	}
public static void main(String[] args) {
System.out.println(new Main1().sum(2.2f, 3.3f));
	System.out.println(my.g);
}
}
