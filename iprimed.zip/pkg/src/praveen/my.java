package praveen;

 public interface my {
   int g=1000;
   double  sum(float a, float b);
}
