package praveen;

 public class HelloWorld {
 protected  int id=100;
   protected  void m()
   {
	   System.out.println("i am  protected");
   }
  protected void  g()
   {
	   System.out.println("default");
   }
   public int b=900;
}
