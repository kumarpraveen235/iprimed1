package com.iprimed.fsd.model;

public class Emp {
   public static void main(String[] args) {
	System.out.println("Hi");
}
}
