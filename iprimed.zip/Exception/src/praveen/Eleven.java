package praveen;
class My
{}
public class Eleven {
public static void main(String[] args) throws  ClassNotFoundException{
  	Class c=Class.forName("praveen.My");// loads the class @ Run time
	System.out.println(c.getName());
}
}
