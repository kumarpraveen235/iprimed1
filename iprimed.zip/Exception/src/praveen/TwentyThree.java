package praveen;
import java.util.*;
class  InvalidAgeException extends  Exception
{
	public InvalidAgeException(String s) {
	   super(s);// invokes super class  constructor
	}
}
public class TwentyThree {
	 public static  void valid(int age)  throws  InvalidAgeException
	 {
		 if (age <18)
		 {
			 throw new InvalidAgeException("wrong age");
		 }
		 else
		 {
			 System.out.println("YOu are elgible to vote");
		 }
	 }
	 public static void main(String[] args) {
		Scanner   sc=new Scanner(System.in);
		System.out.println("enter age");
		int ag=sc.nextInt();
		try {
			          valid(ag);
		}
		catch (InvalidAgeException e) {
			System.out.println("Invalid age  "+e);
			System.out.println(e.getMessage());
		}
	}

}
