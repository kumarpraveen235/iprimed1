package praveen;

public class TwentyOne {
   static  void m()
   {
	   throw new ArithmeticException();
   }
   static   void m1()
   {
	    m();   // default propagated
   }
   public static void main(String[] args) {
	  try {   m1() ;}
	  catch (ArithmeticException e) {
		System.out.println("Handeleed  "+e);
	}
}
}
