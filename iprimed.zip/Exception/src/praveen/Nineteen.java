package praveen;
import  java.util.*;
public class Nineteen {
     public  static  void    check(int age) throws  Exception
     {
    	    if(age < 18) 
    	    {
    	    	throw  new Exception("invalid age");
    	    }
    	    else
    	    {
    	    	System.out.println
    	    	("You  are   greater than or equal to "+age+" and elible to vote");
    	    }
     }
     public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the age");
		int age=sc.nextInt();
		   try
		   {
			     check(age);
		   }
		   catch (Exception e) {
			System.out.println("wrong age "+e);
		}
	}
}
