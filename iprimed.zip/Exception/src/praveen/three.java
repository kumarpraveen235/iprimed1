package praveen;
public class three {
   static  void m()
   {
	   try {
	   int  a[]=new  int[2];
	   a[3]=10/0;
   }

	   catch (Exception e) {
		System.out.println("handeled  through super class "+e);
	}
	   }
   
   
   public static void main(String[] args) {
	m();
}
}