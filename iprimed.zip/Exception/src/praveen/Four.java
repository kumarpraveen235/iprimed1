package praveen;

import java.util.Scanner;

public class Four {
   static   void m()
   {
	   try {
	     String s="144";
	     int    a=Integer.parseInt(s);
	     String[]  s1=new String[10];
	      s1[1]=null;
	      System.out.println(s1[1].length());
   }
	/*
	 * catch (NumberFormatException | ArrayIndexOutOfBoundsException |
	 * NullPointerException e) { System.out.println("Error   "+e); }
	 */  
	   catch (Exception e) {
		   System.out.println("Error  1  "+e);
	}
}
   public static void main(String[] args) {
	m();
}
}
