package praveen;
public class Seventeen {
    public static  int cube(int i)
    {
    		try {
    			int a=10/0;   
    		}
    		catch(ArithmeticException  e)
    		{
    			System.out.println("Error  "+e);
    		}
    		finally {
				System.out.println("always  exceutes");
			}
    	
    return     i*i*i;
    }
    public static void main(String[] args) {
		   System.out.println("Cube  "+cube(4));
	}
}
