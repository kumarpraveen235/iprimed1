package praveen;

import java.io.IOException;

public class Sixteen {
   static   void m() throws IOException
   {
	      throw   new IOException("DEVICE ERROR");
   }
   public static void main(String[] args) {
	  try
	  {
		      m();
	  }
	  catch(IOException e)
	  {
		  System.out.println("Handeled  "+e);
	  }
	  finally {
		System.out.println("alway  executes");
	}
	  
}
}
