package praveen;

public class One {
public static void main(String[] args) {
	try {
	System.out.println("welcome".charAt(10));
	System.out.println(10/0);
}
	catch(ArithmeticException e) {
		System.out.println("Handeled   "+e);
	}
	System.out.println("Rest  of code");
}

}
