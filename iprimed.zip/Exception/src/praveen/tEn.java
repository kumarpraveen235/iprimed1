package praveen;
import  java.util.*;
public class tEn {
       static  void m(int n)
       {
    	   try {
    	   if(n<0)
    	   {
    		   throw new ArithmeticException("invalid no  ");
    		   
    	   }
    	   else
    	   {
    		   System.out.println("u entered  "+n);
    	   }
    	   }
    	   catch (ArithmeticException e) {
		System.out.println("handeled  "+e);
		}
    	   System.out.println("lot of code......");
       }
       public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter  no");
		int n=s.nextInt();
		
			   m(n);
		
	}
}
