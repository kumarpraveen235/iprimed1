package praveen;
class Emp
{
	   void m()  throws  InterruptedException
	   {
		   System.out.println("i am emp");
	   }
}
public class Manager extends Emp {
@Override
void m()  throws InterruptedException
{
	   System.out.println("i am manager");
}
public static void main(String[] args)  {
	try{new Manager().m();}
	catch (Exception e) {
	System.out.println("error  "+e);
	}
}
}
