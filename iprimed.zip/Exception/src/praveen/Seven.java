package praveen;

public class Seven {
   static  void m()
   {
	   try
	   {
	       System.out.println(10/0);
   }
	   catch (ArithmeticException e) {
		try {   int a=10/0;}
		catch(Exception  e1)
		{
			System.out.println("error  1  "+e1);
		}
		   
	System.out.println("Error   "+e);
	}
	   
}
   public static void main(String[] args) {
	m();
}
}
