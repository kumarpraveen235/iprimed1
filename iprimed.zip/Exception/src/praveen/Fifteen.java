package praveen;

public class Fifteen {
   static  void m()
   {
	   try {
		   System.out.println("in try");
		   System.exit(0);;
	      System.out.println("ganesh".charAt(10));
   }
	   catch (NullPointerException e) {
		System.out.println("Handeled   "+e);
	}
	   finally {
		System.out.println("always executes");
	}
	   
}
   public static void main(String[] args) {
	m();
}
}
