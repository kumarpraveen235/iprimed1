package praveen;

public class Second {
    static  void m()
    {
    	try {
    		int a[]=new int[1];
    		a[10]=4;// array index  out of bounds  exception
    	String s=null;
    	System.out.println(s.length());// null pointer  exception
    	String s1="ajay";
    	int k=Integer.parseInt(s1);//   number format exception
    	System.out.println(k);
    }
        
    	
    	catch (NullPointerException  e) {
			System.out.println("Incampatible  type  "+e);
		}
    	catch (ArithmeticException e) {
			System.out.println("handeled  "+e); 
		}
    	catch (Exception e) {
    		System.out.println("handeled through super class  "+e);
    		}
    
    	}
    public static void main(String[] args) {
		m();
	}
}
