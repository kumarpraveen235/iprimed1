package praveen;

public class Eight {
   static  void m()
   {
	     throw  new NullPointerException("null ");
	    
   }
   public static void main(String[] args) {
	   
	  try {m();}
	  catch (NullPointerException e) {
		System.out.println("hadeled  "+e);
	}
}
}
