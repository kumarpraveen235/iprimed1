package praveen;
import java.io.*;
public class nine {
    static  void m()
    {
    	try{throw   new IOException("i/o error");}
    	catch (IOException e) {
			System.out.println("Handled  "+e);
		}
    }
    public static void main(String[] args) {
		    m();
	}
}
