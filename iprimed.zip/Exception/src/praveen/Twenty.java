package praveen;

public class Twenty {
   static  ArithmeticException   a;
    static  void m()
    {
    	  a=new ArithmeticException("arithexception");
    	  throw a;
    }
    public static void main(String[] args) {
		try
		{
			   m();
			   
		}
		catch(ArithmeticException e)
		{
			   
			System.out.println("handeled  "+e);
		try {	throw a;}// rethrown the  exception
		catch(ArithmeticException e1)
		{
			   
			System.out.println("again handeled  "+e1);
		}
		
	}
	
}
}