package praveen;
import java.io.*;
public class TwentyTwo {
   public static  void m()  
   {
	try {   throw new IOException("deviceerror ");}
	  catch (IOException e) {
			System.out.println("handeled   "+e);
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
   }
   static void m1() 
   {
	      m();
   }
   public static void main(String[] args) {
	   m1();
}
}
