package praveen;

public class Two {
     static  void m()
     {
    	 try {
    	    int a[]=new int[10];
    	    a[335]=33;
    	    
    	    try {
    	    	
    	    System.out.println("amar".substring(10,15));
     }// inner try  closes
    	 catch(Exception e)
    	    {
    		 System.out.println("Error  "+e);
    	    }   //  catch  for  inner try close
    	    
}//  outer try closes
    	 catch(ArrayIndexOutOfBoundsException  e)
    	 {
    		 System.out.println("handeled by super class "+e);
    	 }   //  catch for  outer try closes
     }   // method  closes
     public static void main(String[] args) {
		m();  
	}
}
