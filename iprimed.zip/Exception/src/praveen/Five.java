package praveen;

public class Five {
static   int m()
{
	         try
	         {
	        	    int a=10/0;
	         }
	         catch(NullPointerException  e)
	         {
	        	 System.out.println("Handeled   "+e);
	         }
	        return   10*10;
}
public static void main(String[] args) {
	System.out.println(m());
}

}
