package praveen;

public class Six {
   static   void m()
   {
	       try
	       {
	    	        int a=10/0;
	    	        System.out.println(a);
	       }
	       catch(NullPointerException e)
	       {
	    	   System.out.println("out error   "+e);
	    	   System.out.println("inside catch");
	    	   try
	    	   {
	    		   System.out.println("tarun".substring(10));
	    	   }
	    	   catch(ArithmeticException e1)
	    	   {
	    		   System.out.println("in error  "+e1);
	    	   }
	       }
	       
   }
   public static void main(String[] args) {
	m();
}
}
