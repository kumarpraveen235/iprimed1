package praveen;
import  java.sql.*;
public class Fourteen {
 static  void m() throws   SQLException
 {
	    System.out.println("Hi");
 }
 public static void main(String[] args) throws  SQLException {
	   m();
}
}
