package praveen;
import  java.io.*;
public class Thirteen {
    static void   m() throws   IOException
      {
    	 throw   new IOException("device error");
     }
     public static void main(String[] args) throws   IOException {
		m();
	}
}
