package praveen;

public class Another {
   int id;
   String name;
public Another(int id, String name) {
	super();
	this.id = id;
	this.name = name;
}
@Override
public String toString() throws  ArithmeticException{
	return "Another [id=" + id + ", name=" + name + "]";
}
   public static void main(String[] args) {
	Another  a=new Another(1, "ajit");
	System.out.println(a);
}
}
