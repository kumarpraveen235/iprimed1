package praveen;
interface   Ic
{
	   void  m();
	    int g=5;
	    class My
	    {
	    	   void m1()
	    	   {
	    		   System.out.println("Hi");
	    	   }
	    }
}
public class NestClass extends Ic.My implements   Ic {

	@Override
	public void m() {
		System.out.println("Hello");
		
	}
	public static void main(String[] args) {
		 NestClass  n=new NestClass();
		 n.m();n.m1();
		 System.out.println(g);
	}

}
