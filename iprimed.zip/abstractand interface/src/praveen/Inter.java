package praveen;
interface   P
{
	    void m();
	    int x=100;
}
interface   Q
{
	    void m();
	    int y=101;
}
public class Inter implements  P,Q{

	@Override
	public void m() {
		System.out.println("i am  P or Q s  method");
	}
public static void main(String[] args) {
	   Inter   ii=new Inter();
	     ii.m();
	     System.out.println(x+"\t"+y);

}
}
