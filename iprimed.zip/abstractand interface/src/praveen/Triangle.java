package praveen;
abstract class   Shape
{
	   void  n()
	   {
		   System.out.println("i am concrete");
	   }
	     abstract   void   draw();
	     final   static  void s()
	        {
	        	System.out.println("i am static final  concrete  ");
	        }
	     int  a;
	     Shape(int a){ this.a=a;}
	  
}
public  class Triangle extends  Shape {
        public Triangle(int a) {
			super(a);
			System.out.println(a);
		}

		@Override
		void draw() {
			System.out.println("i am drawing triangle");
		}
		public static void main(String[] args) {
			Shape  ss=new Triangle(100);// upcasting
			
			ss.n();
			s();
			ss.draw();
		}
}
