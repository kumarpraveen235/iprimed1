package praveen;
interface  i
{
	    void m();
	       int a=100;
}
interface  i1
{
	    void m1();
	       int a1=10;
}
public class InterFaces implements   i,i1 {

	@Override
	public void m1() {
		System.out.println("i am  m1");
		
	}

	@Override
	public void m() {
	System.out.println("i am  m2");
		
	}
public static void main(String[] args) {
	InterFaces  if1=new InterFaces();
	if1.m();if1.m1();
	System.out.println(a+"\t"+a1);
}
}
