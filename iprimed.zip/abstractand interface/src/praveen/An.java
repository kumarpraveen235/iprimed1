package praveen;

public class An {
	int   a=100;
	   An()
	   {
		   System.out.println("I am  cosntructor");
	   }
void m()
{
	   System.out.println("Welcome");
}
public static void main(String[] args) {
	new An();
	new An().m();
System.out.println(new An().a);
}
}
