package praveen;
interface  i4{
	   void  m1();
	   int k=1;
}
interface  i2{
	   void  m2();
	   int k=11;
}
interface  i3 extends i2,i4{
	   void  m3();
	   int k=21;
}
public class Multi  implements   i3{

	@Override
	public void m1() {
		System.out.println("i am  m1");
		
	}

	@Override
	public void m2() {
		System.out.println("i am  m2");
		
	}

	@Override
	public void m3() {
		System.out.println("I am m3");
		
	}
public static void main(String[] args) {
Multi  mm=new Multi();
  mm.m1();mm.m2();mm.m3();
System.out.println(i4.k+"\t"+i2.k+"    "+i3.k);
}
}
