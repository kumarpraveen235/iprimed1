package praveen;
interface   it1
{
	    void m();
	     void  m1();
	     void m2();
}

abstract class Eg  implements  it1
{
	@Override
	public void m()
	{
		System.out.println("i am m");
	}
}
public class Eg1 extends  Eg {

	@Override
	public void m1() {
	System.out.println("i am m1");
		
	}

	@Override
	public void m2() {
		System.out.println("i am m2");
		
	}
public static void main(String[] args) {
	Eg1  ee=new Eg1();
	   ee.m();ee.m1();ee.m2();
}
}
