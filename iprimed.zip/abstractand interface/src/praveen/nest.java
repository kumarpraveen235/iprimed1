package praveen;
interface   nest1
{
	   int a=100;
	   void m();
	   interface   nest2
	   {
		      void m1();
		        int a1=200;
	   }
}

public class nest  implements   nest1, nest1.nest2{

	@Override
	public void m() {
		System.out.println("outer interface");
		
	}

	@Override
	public void m1() {
		System.out.println("Inner  Interface");
		
	}
public static void main(String[] args) {
	   nest   n=new nest(); n.m();n.m1();
	   System.out.println(nest1.a+"     "+nest1.nest2.a1);
}
}
