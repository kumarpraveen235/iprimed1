package praveen;

abstract  class abs
{
	   abstract String sayHi();
}
interface   ii{
	   void  mm();
}
public class An1 {
	public static void main(String[] args) {
		abs aa=new abs()//    here  anonymous   inner  class is created
				// wih ref var  aa  and extends abstract class abs @ background
				{

					@Override
					String sayHi() {
						return "welcome";
					}
			
				};
				System.out.println(aa.sayHi());
	
     ii   i=new ii()//    here  anonymous   inner  class is created
				// wih ref var  i  and implements  interface ii @ background
    		 {

				@Override
				public void mm() {
					System.out.println("i am interface");
					
				}
    	 
    		 };
    		 i.mm();
	}
	}
