package praveen;

public class Three  extends  Thread{
     @Override
     public  void  run()
     {
    	 System.out.println("i am first thread");
     }
     public static void main(String[] args) {
           Three t=new Three();
        //   System.out.println(t.getId());
          // System.out.println(t.getName());
           //System.out.println(t.getPriority());
           t.setName("iprimed");
           t.setPriority(Thread.MIN_PRIORITY);
           System.out.println(t.getName());
           System.out.println(t.getPriority());
       
           Three t1=new Three();
        //   System.out.println(t.getId());
          // System.out.println(t.getName());
           //System.out.println(t.getPriority());
           t1.setName("iprimed1");
            
           t1.setPriority(Thread.MAX_PRIORITY);
           System.out.println(t1.getName());
           System.out.println(t1.getPriority());
              t1.start();  t.start(); 
	}
} 
