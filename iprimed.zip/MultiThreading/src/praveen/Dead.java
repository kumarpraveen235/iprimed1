package praveen;

public class Dead {
public static void main(String[] args) {
	String  name1="ajay";
	String name2="amit";
	Thread  t1=new Thread()
			{
		@Override
		public void run()
		{
			synchronized (name1) {
				
			
			System.out.println("Thread  1  : locks  name1");
			try { Thread.sleep(1000);}
			catch (InterruptedException e) {
			System.out.println("interrupted   "+e);
			}
			synchronized (name2) {
				
				
				System.out.println("Thread  1  : locks  name2");
		}
			}
}
};
Thread  t2=new Thread()
{
@Override
public void run()
{
synchronized (name2) {
	

System.out.println("Thread  2  : locks  name2");
try { Thread.sleep(1000);}
catch (InterruptedException e) {
System.out.println("interrupted   "+e);
}
synchronized (name1) {
	
	
	System.out.println("Thread  2  : locks  name1");
}
}
}
};
t1.start();t2.start();
}}