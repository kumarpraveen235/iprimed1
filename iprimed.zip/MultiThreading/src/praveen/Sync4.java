package praveen;
import  java.util.*;
class Logic
{
	static  int n;
	    static
	    {
	    	 System.out.println("enter the  limit");
			   Scanner  sc=new Scanner(System.in);
			    n=sc.nextInt();
	    }
	   public synchronized  void  oddshow()
	   {
		  
		   for(int i=1;i<=n;i++)
		   {
			   try {
			   if((i%2!=0))
			   {
				Thread.sleep(1000);   
			   
				   System.out.println(i);
			   }
				
		   }
			   catch (InterruptedException e) {
				System.out.println("interrupted  "+e);
			}
	   }
	   }	   
		   public synchronized  void  evenshow()
		   {
			  
			   for(int i=1;i<=n;i++)
			   {
				   try {
				   if((i%2==0))
				   {
					Thread.sleep(1000);   
				   
					   System.out.println(i);
				   }
					
			   }
				   catch (InterruptedException e) {
					System.out.println("interrupted  "+e);
				}
		   }

}
}
		   class  displayeven extends Thread
		   {
			        Logic  l;
			        public displayeven(Logic l) {
					this.l=l;
					}
			        public  void run()
			        {
			        	  l.evenshow();
			        }
		   }
		   class  displayodd extends Thread
		   {
			        Logic  l;
			        public displayodd(Logic l) {
					this.l=l;
					}
			        public  void run()
			        {
			        	  l.oddshow();
			        }
		   }
public class Sync4 {
public static void main(String[] args) {
	Logic  l=new Logic();
	displayeven  d=new displayeven(l);
	displayodd  dd=new displayodd(l);
	d.start();dd.start();
}
}
