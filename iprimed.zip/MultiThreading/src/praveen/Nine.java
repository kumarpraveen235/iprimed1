package praveen;

public class Nine  extends Thread{
	@Override
	public  void run()
	{
		System.out.println("i am   a thread");
	}

	public static void main(String[] args) {
		Nine  n=new Nine();
		n.start();
		//n.suspend();
		n.stop();
	//	n.resume();
		System.out.println(n.isAlive());
	}

}
