package praveen;
import java.util.*;
public class Eight {
   static  int n;
   static {
	   System.out.println("enter the   limit");
	   Scanner  s=new Scanner(System.in);
	   n=s.nextInt();
	   
   }
   public static void main(String[] args) {
	Runnable  r=new Runnable() {
		
		@Override
		public void run() {
			for(int i=1;i<=n;i++)
			{
			try {
				Thread.sleep(1000);
				System.out.println(i);
			}
			catch (InterruptedException e) {
				System.out.println("Error  "+e);
				}
			}
		}
	};
	   Thread   t=new Thread(r);
	   t.start();
}
}
