package praveen;
import java.util.*;
class   Table
{
	    public   synchronized void  print(int n)
	    {
	    	 for(int i=1;i<11;i++)
	    	 {
	    		 try
	    		 {
	    			 Thread.sleep(1000);
	    			 System.out.println(i*n);
	    		 }
	    		 catch (InterruptedException e) {
				System.out.println("interrupted  "+e);	
	    		 }
	    	 }
	    }
}
class  Four1  extends Thread
{
	
	int n;Table  t;
	Four1(Table t)
	{
		this.t=t;
		Scanner  s=new Scanner(System.in);
		System.out.println("enter the  no");
		n=s.nextInt();
		
	}
	@Override
	public  void run()
	{
		t.print(n);
	}
}
class  Seven1  extends Thread
{
	int n;Table  t;
	Seven1(Table t)
	{
		this.t=t;
		Scanner  s=new Scanner(System.in);
		System.out.println("enter the  no");
		n=s.nextInt();
		
	}
	@Override
	public  void run()
	{
		t.print(n);
	}
}

public class Sync1 {
public static void main(String[] args) {
	Table   t=new Table();
	Four1   f=new Four1(t);
	Seven1  s=new Seven1(t);
	f.start();s.start();
}
}
