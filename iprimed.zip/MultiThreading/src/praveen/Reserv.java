package praveen;
class Reservation implements Runnable
{
	 int   avaialble=1;
	 int  wanted;
	 public  Reservation(int i)
	 {
		   wanted=i;
	 }
	@Override
	public void run() {
		synchronized (this) {
			System.out.println("available births  "+avaialble);
			if(avaialble >= wanted)
			{
				String     name=Thread.currentThread().getName();
				System.out.println(wanted+" births reserved for   "+name);
				try
				{
					Thread.sleep(1500);
					avaialble=avaialble-wanted;
				}
				catch (Exception e) {
					// TODO: handle exception
				}
			}else
			{
				 System.out.println("Sorry  no births  available  ");
			}
		}
	}
}
public class Reserv {
	public static void main(String[] args) {
		Reservation   r=new Reservation(1);//    1 person  reserves  1 birth
		Thread  t=new Thread(r);
		Thread  t1=new Thread(r);
		t.setName("first person");
		t1.setName("Second person");
		t.start();t1.start();
	}

}
