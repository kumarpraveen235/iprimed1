package praveen;
class   Five1 extends Thread
{
	   @Override
	   public  void run()
	   {
		   System.out.println(" i am  from   five1");
	   }
}
public class Five extends  Five1 implements Runnable {

	
	
	@Override
	public void run() {
		  super.run();
		for(int i=1;i<=5;i++)
		{
			try {
				Thread.sleep(1000);System.out.println(i);
			}
			catch (InterruptedException e) {
			System.out.println("INTERRUPTED  "+e);
			}
		}

		
	}
public static void main(String[] args) {
	 Five  f=new Five();
	 Thread  t=new Thread(f);
	 t.start(); 
	 }
}
