package praveen;

public class One extends Thread{
@Override
public  void run()
{
	System.out.println("My first  thread");
}
public static void main(String[] args) {
	One o=new One();
	One  o1=new One();
	o.start();o1.start();
	o.start();
}
}
