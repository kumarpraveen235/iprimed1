package praveen;
class Customer
{
	   int amt=10000;
	   
	   public  synchronized  void withdraw(int amt)
	   {
		   System.out.println("going for  withdrawal");
		   if(this.amt<amt)
		   {
			   System.out.println("Less amount. wait for deposit");
			   try
			   {
				   wait(5000);
			   }
			   catch (InterruptedException e) {
				System.out.println("Interrupted  "+e);
			}
		   }
		   this.amt=this.amt-amt;
		   System.out.println("withdrawal has been done");
	   }
	   
	   public  synchronized  void deposit(int amt)
	   {
		   System.out.println("going for  deposit");
		   this.amt=this.amt+amt;
		   System.out.println("deposit has been done");
	 notify();// wakes up the  withdrawal thread
	   }
}
class Inter
{
	 public static void main(String[] args) {
		 Customer  c=new Customer();
		 Thread t1=new Thread()
				 {
			@Override
			public  void run()
			{
				    c.deposit(10000);
			}
		 };
		 Thread t2=new Thread()
		 {
	@Override
	public  void run()
	{
		    c.withdraw(15000);
	}
 };
 t2.start();t1.start();
	}
}