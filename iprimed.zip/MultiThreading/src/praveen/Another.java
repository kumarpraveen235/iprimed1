package praveen;

public class Another  extends Thread{
@Override
public  void run()
{
	 for(int i=1;i<=5;i++)
	 {
		 try
		 {
			 Thread.sleep(1000);
			 System.out.println(i);
		 }
		 catch (InterruptedException e) {
			System.out.println("interrupted  "+e);
		}
	 }
}
public static void main(String[] args) throws InterruptedException {
	Another   f1=new Another();
	Another   f2=new Another();
	Another   f3=new Another();
	f1.start();
	f1.join();
	f2.start();f3.start();
	System.out.println(f1.isAlive());
	System.out.println(f2.isAlive());
	System.out.println(f3.isAlive());
}
}
