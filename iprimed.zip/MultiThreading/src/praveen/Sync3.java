package praveen;

public class Sync3 {
public static void main(String[] args) {
	String name="raj", name1="ravi";
	Thread t1=new Thread()//@back ground  anonymous  inner class  created
			//  which extends  Thread class
			{
		@Override
	public  void run()
	{
			synchronized (name) {   
				System.out.println("thread 1  locked  raj");
			}
				try { Thread.sleep(5000);}
				catch (InterruptedException e) {
					System.out.println("Interrupted  "+e);
				}
				synchronized (name1) {
					System.out.println("thread1  locked ravi");
				}
			
	}
			};
	t1.start();		
}
}
