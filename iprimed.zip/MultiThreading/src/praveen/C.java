package praveen;
class A extends Thread
{
	@Override
	public  void run()
	{
		System.out.println("1st Thread");
	}
	
}
class B extends Thread
{
	@Override
	public  void run()
	{
		System.out.println("2nd Thread");
	}
	
}
public class C {
	public static void main(String[] args) {
		

   A aa=new A();
   A aa1=new A();
   B bb=new B();
   B bb1=new B();
     aa.start();aa1.start();bb.start();bb1.start();
	}}
