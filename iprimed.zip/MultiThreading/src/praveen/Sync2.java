package praveen;

import java.util.*;
class   Table1
{
	    public   synchronized  static void  print(int n)
	    {
	    	 for(int i=1;i<11;i++)
	    	 {
	    		 try
	    		 {
	    			 Thread.sleep(1000);
	    			 System.out.println(i*n);
	    		 }
	    		 catch (InterruptedException e) {
				System.out.println("interrupted  "+e);	
	    		 }
	    	 }
	    }
}
class   Three1 extends Thread
{
	int n;
	Three1(){
	Scanner  sc=new Scanner(System.in);
	System.out.println("eneter the  no");
	n=sc.nextInt();
	}
	@Override
	public  void run()
	{
		Table1.print(n);
	}
}
class  Two1  extends Thread
{
	int n;
	Two1(){
	Scanner  sc=new Scanner(System.in);
	System.out.println("eneter the  no");
	n=sc.nextInt();
	}
	@Override
	public  void run()
	{
		Table1.print(n);
	}
}

public class Sync2 {
public static void main(String[] args) {

	Three1   f=new Three1();
	Two1  s=new Two1();
	f.start();s.start();
}
}
