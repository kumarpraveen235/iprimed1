package praveen;

public class Seven  extends Thread{
    @Override
    public  void run()
    {
    	for(int i=1;i<=5;i++)
    	{
    		try
    		{
    		
    			System.out.println(i);
    			Thread.sleep(1000);
    		}
    		catch (InterruptedException e) {
				System.out.println("Interrupted   "+e);
			}
    	}
    }
    public static void main(String[] args) {
		Seven s=new Seven();
		s.run();
		s.interrupt();
		
		System.out.println(s.isInterrupted()+"\t"+s.isAlive());
	}
}
