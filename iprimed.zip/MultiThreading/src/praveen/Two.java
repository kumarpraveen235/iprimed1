package praveen;
import java.util.*;
public class Two extends Thread {
	static int n;
	static {
		
		Scanner  sc=new Scanner(System.in);
		System.out.println("enter  the size");
		 n=sc.nextInt();
		
	}
	
	@Override
	public void run() 
	{
		
		    for(int i=1;i<=n;i++)
		    {
		    try {	Thread.sleep(1000);
		    
		    	System.out.println(i);
		    }
		    catch (InterruptedException e) {
		System.out.println("interrupted  "+e);
			}
		    }
	}
	public static void main(String[] args )  {
		Two t1=new Two();
		Two t2=new Two();
		Two t3=new Two();
//		t1.start();t2.start();t3.start();
		t1.run();t2.run();t3.run();
	}
   
}
