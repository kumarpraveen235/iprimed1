package praveen;

public class Six {
public static void main(String[] args) throws InterruptedException{
	Thread  t;
	t=Thread.currentThread();
	System.out.println(t);
	t.setName("iprimed");
	t.setPriority(Thread.MAX_PRIORITY);
	System.out.println(t);
	for(int i=1;i<=5;i++)
	{
		Thread.sleep(1000);
		System.out.println(i);
	}
}
}
