package praveen;

public class Ten extends   Thread {
	
	@Override
	public  void run() {
		System.out.println("i am  daemon");
	}
	public static void main(String[] args) {
		Ten t=new Ten();
	//	Thread   tt=new Thread(t);
		t.setDaemon(true);
		
	//System.out.println(t.getPriority());
	t.start();
	}

}
