package praveen;

public class Two {
	   static  int b=50;
   static
   {
	     int a=100;
	      System.out.println("I AM  static  block"+(a+b));
   }
   static   void m()
   {
	   System.out.println("I am static  method");
   }
   void m1() {
	   System.out.println("i am  instance  method");
   }
	Two(){
		System.out.println("i am  constructor");
	}
	      public static void main(String[] args) {
	    	  m();
			Two  t=new Two();
			t.m1();
		}
}
