package praveen;
class Outer1
{
	  private    int data=100;
	  protected    class  Inner
	      {
	    	      void  m1()
	    	      {
	    	    	  System.out.println(data);
	    	      }
	      }
	      
}
public class Outer {
public static void main(String[] args) {
	Outer1   o=new Outer1();
	Outer1.Inner  oi=o.new Inner();
	  oi.m1();
}
}
