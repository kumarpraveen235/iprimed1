package praveen;

public class Main {
public static void main(String[] args) {
	System.out.println(One.a);
	One o=new One();
	o.m();
	One.m1();
}
}
