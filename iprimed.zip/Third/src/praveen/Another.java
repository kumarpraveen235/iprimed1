package praveen;

public class Another {
      int data=100;
      int data1=200;
      class Inner
      {
    	      void  m1()
    	      {
    	    	  System.out.println(data);
    	      }
    	      void m2()
    	      {
    	    	     m1();
    	    	  System.out.println(data1);
    	      }
      }
      void m()
      {
    	     Inner  i=new Inner();
    	     i.m2();
      }
      public static void main(String[] args) {
		Another  a=new Another();
		a.m();
	}
      
}
