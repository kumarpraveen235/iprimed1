package praveen;

public class Local {
     private int a=100;
     void m()
     {
    	   int a1=200;  // local varaible  must be default / final
    	 System.out.println("I am method of outer class");
    	final class LocalInner
    	 {
    		    void m1()
    		    {
    		    	System.out.println(a+"\t"+a1);
    		    	// must access  default / final local (a1) var
    		    }
    	 }
    	 
    	 LocalInner   li=new LocalInner();
    	    li.m1();
     }
     public static void main(String[] args) {
		    Local  l=new Local();
		        l.m();
	}
}
