package praveen;

public class MemberInner {
	 private  int data=100;
	 void m()   /// outer class method
	    {
	    	    Inner  i=new Inner();
	    	        i.m1();
	    }
	  private class Inner
	     {
	    	     void m1()   //  inner class method
	    	     {
	    	    	 System.out.println(data);
	    	     }
	   }
	   
	public static void main(String[] args) {
		MemberInner   mi=new MemberInner();
		   mi.m();
	}
}
