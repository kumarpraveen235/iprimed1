package praveen;

public class One {
    static   int a=100;
       void m()
       {
    	   System.out.println("I am  instance method");
       }
      static  void m1()
      {
    	  System.out.println("I am  static method");
      }
}
