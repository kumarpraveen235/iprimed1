package praveen;

public class Thress {
	
	
	   static  int a;//  blank static  varaible
	   
	   
	   static {
		   a=100;
		   System.out.println(a);
	   }
	   public static void main(String[] args) {
		System.out.println("hi");
	}
}
