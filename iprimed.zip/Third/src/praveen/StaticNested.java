package praveen;

 class StaticNested1 {
    private static  int a=100;
  protected  static  class    Inner
    {
    	static  void m()
    	  {
    		  System.out.println(a);
    	  }
    }
}
class  StaticNested{
    public static void main(String[] args) {
   StaticNested1.Inner.m();
       
	}
}
