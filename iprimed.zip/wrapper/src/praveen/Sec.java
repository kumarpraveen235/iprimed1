package praveen;

import java.util.Scanner;

public class Sec {
public static void main(String[] args) {
	double  d=7879.64;
	Double dd=new Double(d);//   auto boxing
	System.out.println(dd);
	double  db=dd.doubleValue(); // un boxing
	System.out.println(db);
	System.out.println(Double.isInfinite(3.0/0.0));
	System.out.println(Double.isNaN(0.0/0.0));
	System.out.println(Double.max(4214.13, 24235.9));
	Scanner  sc=new Scanner(System.in);
	System.out.println("enter a string");
	String str=sc.next();
	try
	{
		   double g=Double.parseDouble(str);
		    System.out.println("U enetered  "+g);
	}
	catch (NumberFormatException e) {
		System.out.println("Invalid no  "+e);
		// TODO: handle exception
	}
	char ch='c';
	Character  c1=new Character(ch);//  auto boxing
			System.out.println(c1);
			char ch3=c1.charValue(); // unboxing
			System.out.println(ch3);
			System.out.println(Character.isDigit('9'));
			
	
}
}
