package praveen;
import  java.util.*;
public class First {
   public static void main(String[] args) {
	int   i=10;
	Integer ii=new Integer(i);//autoboxing
	System.out.println(ii);
	String  s="1234";
	Integer ii1=new Integer(s);
	System.out.println(ii1);
	
	int   p=ii1.intValue();// un boxing
	System.out.println(p);
	System.out.println(Integer.toBinaryString(20));
	System.out.println(Integer.toHexString(20));
	System.out.println(Integer.toOctalString(20));
	System.out.println(Integer.sum(10,10)+"\t"+Integer.max(86,765));
	Scanner  sc=new Scanner(System.in);
	System.out.println("enter a string");
	String str=sc.next();
	try
	{
		    int g=Integer.parseInt(str);
		    System.out.println("U enetered  "+g);
	}
	catch (NumberFormatException e) {
		System.out.println("Invalid no  "+e);
		// TODO: handle exception
	}
}
}
