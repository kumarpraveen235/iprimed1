package praveen;

public class Jump {
public static void main(String[] args) {
	  
		       for(int i=1; i<6; i++)
		       {
		    	   System.out.print("i   "+i+"   :        j:    ");
		    	   
		    	   for(int j=1;j<6;j++)
		    	   {
		    		   System.out.print(j);
		    		   if(j==4) break;
		    	   }
		    	   if(i==2) break;
		    	   System.out.println();
		       }
}
}
