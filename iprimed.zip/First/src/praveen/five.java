package praveen;

import java.util.Scanner;

public class five {
public static void main(String[] args) {
	Scanner   sc=new Scanner(System.in);
	System.out.println("enter the  row and col   size");
	int m=sc.nextInt();
	int n=sc.nextInt();
	int a[][]=new int[m][n];
	
	System.out.println("enter the elements");
	for(int[] e:a)
	{
		 
		for(int e1=0; e1<e.length;e1++)
		{
			e[e1]=sc.nextInt();
		}
	}
	System.out.println(" elements are");
	for(int[] e:a)
	{
		for(int e1:e)
		{
	System.out.print(e1+"  ");
		}
		System.out.println();
	}
}
}
