package praveen;
import java.util.*;
public class Statement1 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the  month");
	int m=sc.nextInt();
	if(m>12) {
		System.out.println("invalid  month");
	}
	else
	if((m==1)||(m==12)||(m==11)||(m==10))
	{
		System.out.println("winter");
	}
	else
		if((m==9)||(m==8)||(m==7)||(m==6))
		{
			System.out.println("spring");
		}
		else
		{
			System.out.println("summer");
		}
}
}
