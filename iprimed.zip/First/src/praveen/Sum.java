package praveen;

import  java.util.*;
 public class Sum {
public static void main(String[] args) {
	/*
	 * int a=1; int b=2; int c=++b;// b=3 c=3 System.out.println(c+"\t"+b); int
	 * d=a++;// d=1 a=2 System.out.println(d+"\t"+a); float e=(a+b)/(c*d);
	 * System.out.println(e);
	 */
	/*
	 * int a=10; System.out.println(a++); System.out.println(a--);
	 * System.out.println(a); System.out.println(a%5);
	 */
	/*
	 * System.out.println(10&15); System.out.println(10|15);
	 * System.out.println(~(-20)); System.out.println(~22);
	 * 
	 * System.out.println(20>>2); //System.out.println(Integer.toBinaryString(130));
	 * 
	 * System.out.println(130>>4); System.out.println(20<<2);
	 * 
	 * System.out.println(6^10);
	 */

	/*
	 * boolean a=true, b=false, c=true, d=true;
	 * 
	 * System.out.println((a&b)|(b|c) ); System.out.println(!a);
	 */

	   boolean a=true, b=false;
	   
	   System.out.println(a&&b);
	   
	   
}
}