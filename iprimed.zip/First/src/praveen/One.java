package praveen;

public class One {
public static void main(String[] args) {
byte    b=30;
   int   a=b;   // IMPLICIT   TYPE  CASTING
   System.out.println(a);
   
   int  k1=300;
   byte  b1=(byte)k1;//  explicit type casting
   System.out.println(b1);
   
   
   float  f=75868.75870f;
   int j=(int)f;
   System.out.println(j);
   System.out.println((int)'d');
   System.out.println((char)67);
   
   byte   p=50;
   p=(byte)(p*2);
  System.out.println(p);
   
}
}
