package praveen;

public class Cont {

public static void main(String[] args) {
	System.out.println("odd nos");
	for(int i=1; i<21;i++)
	{
		if((i%2)==0) continue;
		System.out.println(i);
	}
	System.out.println();
	System.out.println("even nos");
	for(int i=1; i<21;i++)
	{
		if((i%2)!=0) continue;
		System.out.println(i);
	}
}
}
