package praveen;
import  java.util.Scanner;
public class statements {
	public static void main(String[] args) {
		System.out.println("enter  1st  no");
		Scanner sc=new Scanner(System.in);
	int n1=sc.nextInt();
	if(n1==1)
	{
	System.out.println("Enter  2nd No");
	int n2=sc.nextInt();
	if(n2==2)
	{
		System.out.println("both are  correct");
	}
	else
	{
		System.out.println("2nd no is in correct");
	}
	}
	else
	{
		System.out.println("1st no is  incorrect");
	}
	}
   
}
