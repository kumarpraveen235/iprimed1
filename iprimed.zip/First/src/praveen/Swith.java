package praveen;

import java.util.Scanner;

public class Swith {
public static void main(String[] args) {
	Scanner  sc=new Scanner(System.in);
	System.out.println("enter  the day");
	String d=sc.next();
	switch(d)
	{
	case  "monday": System.out.println("Monday");break;
	case  "tuesday": System.out.println("Tuesday");break;
	case  "wedday": System.out.println("Wedday");break;
	case  "thursday": System.out.println("Thursday");break;
	case  "friday": System.out.println("Friday");break;
	default: System.out.println("weekend");
	}
}
}
