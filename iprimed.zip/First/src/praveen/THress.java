package praveen;

public class THress {
public static void main(String[] args) {
	int a=1,b=2, c=3;
System.out.println((a<b)||(a<b++));
System.out.println(b);

int  aa=(100>101)? 5:10;
System.out.println(aa);
}
}
