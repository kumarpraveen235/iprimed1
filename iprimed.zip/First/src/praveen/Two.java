package praveen;
import java.util.Scanner;
public class Two {
public static void main(String[] args) {
	float   f1,f2,d1;
	Scanner  s=new Scanner(System.in);
	System.out.println("Enter the 2 nos");
   f1=s.nextFloat(); f2=s.nextFloat();
   d1=f1+f2;
     System.out.println(d1);
	System.out.println("enter character");
	String    ss=s.next();
	System.out.println(ss.charAt(0));
}
}
