package stack;
import    java.util.*;

public interface stack {
  void push(Scanner   s);
  void pop();
  void display();
  
}
