package stack;
@FunctionalInterface
interface abcd {
void m();
default   void m1()
{
	System.out.println("hi");
}
}
