package stack;
import  java.util.*;
class StackProgram1  implements stack{
	int top,n; int arr[];
	Scanner   sc=new Scanner(System.in);
	  public StackProgram1() {
		  top=-1;
			
			System.out.println("enter the  size of the stack");
			 n =sc.nextInt();
			arr=new int[n];
	}
	   boolean isEmpty()
	   {
		        return   ( top<0);
	   }
	@Override
	public void push(Scanner s) {
      try {
    	  
        
		if(top==n-1)
		{
			//System.out.println("overflow");
			throw  new ArithmeticException("full");
			
		
			
		}
		else
		{
			System.out.println("enter the value");
			int  v=s.nextInt();
			top++;
			arr[top]=v;
			System.out.println("element pushed   "+v);
					}		
      }
      catch (ArithmeticException e) {
			System.out.println("stack  is  full  "+e);
		}
	}
	@Override
	public void pop() {
		try {
		if(top==-1)
		{
			throw new ArithmeticException("empty");
		}
		else
		{
			top--;
			System.out.println("element popped ");
			
		}	}
		catch (Exception e) {
			System.out.println("stack is  empty   "+e);
		}
	
	}

	@Override
	public void display() {
	System.out.println("printing elemeents of stack");
	for(int i=top; i>=0; i--)
	{
		System.out.println(arr[i]);
	}
	}
	

}
class StackProgram
{
	public static void main(String[] args) {
		int  ch=0;
		Scanner  sc=new Scanner(System.in);
		StackProgram1   s1=new StackProgram1();
		System.out.println("**********Stack operations***********\n");
		System.out.println("\n-----------------------------------------\n");
		while(ch!=4)
		{
			System.out.println("\n Choose  1 from  below options\n");
			System.out.println("\n1.Push\n2.Pop\n3.display\n4.exit\n");
			System.out.println("\nenter choice\n");
			ch=sc.nextInt();
			switch (ch) {
			case 1: {
				
				s1.push(sc);break;
			}
	case 2: {
				
				s1.pop();break;
			}
	case 3: {
		
		s1.display();break;
	}
	case 4: {
		System.out.println("exiting............");
		System.exit(0);
		break;
		}
			default:
				System.out.println("please enter valid choice");
			}
		}
		
	}
}