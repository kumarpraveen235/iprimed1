package praveen;
import java.util.*;
class Stud1
{
	  int id;
	  String name;
	  String  subject;
	  int marks;
	
	public Stud1() {
		
	}

	public Stud1(int id, String name, String subject, int marks) {
		super();
		this.id = id;
		this.name = name;
		this.subject = subject;
		this.marks = marks;
	}
	  
}
public class Stud {
public static void main(String[] args) {
	Scanner   sc=new Scanner(System.in);
	System.out.println("enter the   student array size");
	int    n=sc.nextInt();
	Stud1  s[]=new Stud1[n];
	System.out.println("enter   "+n+"      students  info");
	for(int i=0;i<s.length;i++)
	{
		    s[i]=new Stud1();
		    s[i].id=sc.nextInt();
		    s[i].name=sc.next();
		    s[i].subject=sc.next();
		    s[i].marks=sc.nextInt();
		    
	}
	System.out.println("stud  info");
	for(int i=0;i<s.length;i++)
	{
		System.out.println(s[i].id+"\t"+s[i].name+"\t"+s[i].subject+"\t"+s[i].marks);
	}
}
}
