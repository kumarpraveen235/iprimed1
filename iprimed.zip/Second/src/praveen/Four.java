package praveen;

public class Four {
     void m(Four f)
     {
    	 System.out.println("welcome");
     }
     void m1()
     {
    	 m(this);
     }
     public static void main(String[] args) {
		Four  f=new Four();
		f.m1();
	}
}
