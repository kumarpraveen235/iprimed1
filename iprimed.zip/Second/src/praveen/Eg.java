package praveen;

public class Eg {
   static int count=0;
   Eg()
   {
	       count++;
	       System.out.println(count);
   }
   public static void main(String[] args) {
	   
	   
	Eg e1=new Eg();

	Eg e2=new Eg();

	Eg e3=new Eg();
	Eg e4=new Eg();
}
}
