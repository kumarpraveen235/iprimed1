package praveen;

public class This {
     int id;
     String name;
     This(int  id, String name)
     {
    	   this.id=id;
    	  this. name=name;}
     void  m()
     {

  	   System.out.println(id+"\t"+name);
   
     }
     public static void main(String[] args) {
		This  t=new This(1, "sunny");
		       t.m();
	}
}
