package praveen;

public class Person1 {
    int id;
    String name;
     String   company="cts";
public Person1(int id, String name) {
	super();
	this.id = id;
	this.name = name;
}
    void d()
    {
    	System.out.println(id+"\t"+name+"\t"+company);
    }
    public static void main(String[] args) {
		Person1 p1=new Person1(1, "raju");
		Person1 p2=new Person1(2, "asha");
		p1.d();p2.d();
	}
}
