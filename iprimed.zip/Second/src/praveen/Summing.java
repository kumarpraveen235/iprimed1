package praveen;

public class Summing {
      int a, b, c;

	public Summing() {
		
		System.out.println("Default  constructor");
	}
  
	public Summing(int a, int b) {
	this();
			this.a = a;
		this.b = b;
		System.out.println("sum of  2 no "+(a+b));
	}

	public Summing(int a, int b, int c) {
	this(a,b);
		this.c = c;
		System.out.println("sum of  3 no  "+(a+b+c));
	}
	public static void main(String[] args) {
	Summing   s=new Summing();
	Summing s1=new Summing(1,2);
	Summing s2=new Summing(3,3,3);
	}
    
      
}
