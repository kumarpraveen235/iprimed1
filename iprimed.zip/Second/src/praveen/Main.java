package praveen;

class   Cube {
   int  i;
    public Cube(int i1)
   {
	   i=i1;
	   System.out.println(i*i*i);
   }
	public Cube() {
		System.out.println("i am  default");
	}
}
class Main
{
	public static void main(String[] args) {
		Cube c=new Cube(7);//  cannot instatiate a private con from out of class
		Cube  c1=new Cube(6);
		
	}
}
