package praveen;
import  java.util.*;
class Student1
{
	  int id;
	  String name;
	  int age;
	  void set(int id1, String name1, int age1)
	  {
		    id=id1;name=name1;age=age1;
	  }
}
public class Student {
   public static void main(String[] args) {
	Scanner  sc=new Scanner(System.in);
	System.out.println("Enter the Array size");
	int n=sc.nextInt();
	Student1[]  s=new Student1[n];
	System.out.println("enter the  "+n+"  students  id name and age");
	for(int i=0; i<s.length;i++)
	{
		s[i]=new Student1();
		
		s[i].id=sc.nextInt();
		s[i].name=sc.next();
		s[i].age=sc.nextInt();
		s[i].set(s[i] .id,s[i].name,s[i].age);
	
	}
	System.out.println("Student  list  is");
	for(int i=0; i<s.length;i++)
	{
		System.out.println(s[i].id+"\t"+s[i].name+"\t"+s[i].age);
	}
}
}
