package praveen;
import java.util.*;
class  Sum
{
	int a, b;
	void add(int a1, int b1)
	{
		  a=a1; b=b1;
	}
	int  output()
	{
		  return a+b;
	}
}

class  Product
{
	double a, b;
	void mul (double a1, double b1)
	{
		  a=a1; b=b1;
	}
	double output()
	{
		  return a*b;
	}
}

public class Calculator {
public static void main(String... args) {
	Sum  s=new Sum();
	Product p=new Product();
	System.out.println(s+"\t"+p);
	Scanner  sc=new Scanner(System.in);
	System.out.println("enter   2  integers");
	int n1=sc.nextInt();int n2=sc.nextInt();
	System.out.println("enter   2  doubles");
	double n3=sc.nextDouble();double n4=sc.nextDouble();
		s.add(n1,n2);	
		p.mul(n3,n4);
		
		System.out.println("Sum   "+s.output());
		System.out.println("Product "+p.output());
		
		
}
}
