package praveen;

public class Man {
   int id;
   String name;int age;

public Man(int id, String name, int age) {
	//super();
	this.id = id;
	this.name = name;
	this.age = age;
}
   public  Man(Man m)
   {
	   id=m.id;
	   name=m.name;
	   age=m.age;
   }
   void  d()
   {
	   System.out.println(id+"\t"+name+"\t"+age);
   }
   public static void main(String[] args) {
	 Man m=new Man(1,"john",29);
	 Man m1=new Man(m);
	 m.d();m1.d();
}
}
