package praveen;
class Person
{
	    int id;
	    String name;
	    int age;
	    
	   private Person()   //   default  con
	    {
	    	System.out.println("i am default");
	    }
	public    Person(int id1, String name1, int age1)   // parameterized  con
	    {
	    	   id=id1;name=name1;age=age1;
	    }
	    public void Person()
	    {
	    	System.out.println(  id+"\t"+name+"\t"+age);
	    }
	    public static void main(String[] args) {
			Person p=new Person();
			Person p1=new Person(1, "lokesh", 30);
			p1.Person();
		}
}