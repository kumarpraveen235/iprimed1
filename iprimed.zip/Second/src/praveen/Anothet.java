package praveen;

public class Anothet {
      void m()
      {
    	  System.out.println("hi");
      }
      public Anothet()
      {
    	  System.out.println("I am default");
      }
      public Anothet( int i) {
System.out.println(i);
	}
      public static void main(String[] args) {
		Anothet  a=new Anothet();
		Anothet  a1=new Anothet(10);
		a.m();
	}
}
