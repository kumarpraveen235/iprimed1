package praveen;

public class Three {
        void m()
        {
        	System.out.println("I am  method");
        }
        void m1()
        {
        	this.m();
        }
        void m2()
        {
        	m1();
        }
        public static void main(String[] args) {
			Three   t=new Three();
			    t.m2();
		}
}
