package praveen;
import java.util.*;
class Emp1
{
	   int id;
	   String name;
	   String des;
	   double  basic;
	public Emp1(int id, String name, String des, double basic) {
		//super();
		this.id = id;
		this.name = name;
		this.des = des;
		this.basic = basic;
	}
	   
	public   double   totalSal()
	{
		double da=(150.00*basic)/100.00;
		double hra=(30.00*basic)/100.00;
		double tax=(2.00*basic)/100.00;
		double netsal=basic+hra+da-tax;
		return  netsal;
		
	}
	public  void  display()
	{
		 System.out.println(id+"\t"+name+"\t"+des);
		 System.out.println("Net salary  "+totalSal());
	}
	
}
public class Emp {
public static void main(String[] args) {
	Scanner  sc=new Scanner(System.in);
	System.out.println("enter the emp id, name , des and basic slaary");
	int id=sc.nextInt();
	String name=sc.next();
	String des=sc.next();
	double  bs=sc.nextDouble();
	Emp1  e1=new Emp1(id, name, des, bs);
	e1.display();
}
}
