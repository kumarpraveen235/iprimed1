package praveen;
class Mo
{
    double  m(float a, float b)
{
      return  a+b;
}
    String m(String  a, String b)
{
      return a+b;
}

public static void main(String[] args) {

     Mo aa=new Mo();
     System.out.println(aa.m(33.22f,11.22f));
      System.out.println(aa.m('a','a'));
}
}