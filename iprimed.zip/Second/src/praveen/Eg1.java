package praveen;
class  Eg1
{
   static int  s=100;
  public static void main(String[] args) {
	   
	   System.out.println(s);
}
}
