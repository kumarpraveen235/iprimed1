package praveen1;
import java.util.*;
class Student1
{
	   String name;
	   int std;
	public Student1(String name, int std) {
		super();
		this.name = name;
		this.std = std;
	}
	   
}
class  StdComp implements Comparator<Student1>
{

	@Override
	public int compare(Student1 o1, Student1 o2) {
		if(o1.std==o2.std) return 0;
		if(o1.std>o2.std) return 1;
		else return -1;
		
	}
	
}
class  NameComp implements Comparator<Student1>
{

	@Override
	public int compare(Student1 o1, Student1 o2) {
		return o1.name.compareTo(o2.name);
		
	}
	
}
class Subject
{
	String sname;
	int marks;
	public Subject(String sname, int marks) {
		super();
		this.sname = sname;
		this.marks = marks;
	}
	
}
public class One {
 public static void main(String[] args) {
	Student1 s1=new Student1("geetha", 7);
	Student1 s2=new Student1("Latha",8);
	Student1 s3=new Student1("deepa", 9);
	Subject  sub1=new Subject("maths", 90);
	Subject  sub2=new Subject("physics", 80);
	Subject  sub3=new Subject("englich", 70);
	TreeMap<Student1, Subject>  h=new TreeMap<Student1, Subject>(new NameComp());
	h.put(s1, sub1);h.put(s2, sub2);h.put(s3, sub3);
	Set<Student1>  st=h.keySet();
	Iterator<Student1> i=st.iterator();
	while(i.hasNext())
	{
		Student1  st1=i.next();
		Subject su=h.get(st1);
		System.out.println(st1.name+"  studying in "+st1.std+
				"  class got  "+su.marks+"  marks  in "+su.sname);
	}
  System.out.println();System.out.println();
	
  TreeMap<Student1, Subject>  h1=new TreeMap<Student1, Subject>(new StdComp());
	h1.put(s1, sub1);h1.put(s2, sub2);h1.put(s3, sub3);
	Set<Student1>  st1=h1.keySet();
	Iterator<Student1> i1=st1.iterator();
	while(i1.hasNext())
	{
		Student1  st2=i1.next();
		Subject su=h.get(st2);
		System.out.println(st2.name+"  studying in "+st2.std+
				"  class got  "+su.marks+"  marks  in "+su.sname);
	}
	
}
}
