package praveen1;
import java.util.*;
public class Two {
public static void main(String[] args) {
	Properties  p=new Properties();
	p.put("driver", "com.mysql.cj.jdbc.Driver");
	p.put("url", "jdbc:mysql://localhost:3306/iprimed");
	p.put("user", "root");
	p.put("pass", "123456");
	System.out.println(p);
	System.out.println(p.getProperty("driver"));
}
}
