package praveen;
import java.util.*;
class  Student
{
	  String name;
	  String  city;
	public Student(String name, String city) {
		super();
		this.name = name;
		this.city = city;
	}
	  
}
class  Course
{
	    String cname;
	    int sem;
		public String getCname() {
			return cname;
		}
		public void setCname(String cname) {
			this.cname = cname;
		}
		public int getSem() {
			return sem;
		}
		public void setSem(int sem) {
			this.sem = sem;
		}
	    
}
public class Three {
     public static void main(String[] args) {
		Student  s1=new Student("ajit", "goa");
		Student  s2=new Student("raj", "pune");
		Student  s3=new Student("ajay", "agra");
		Course  c1=new Course();
		c1.setCname("Btech");c1.setSem(4);
		Course  c2=new Course();
		c2.setCname("MCA");c2.setSem(2);
		Course  c3=new Course();
		c3.setCname("MBA");c3.setSem(3);
		LinkedHashMap<Student, Course>  h=new LinkedHashMap<Student, Course>();
		h.put(s1, c1);h.put(s2, c2);h.put(s3, c3);
		Set<Student> s=h.keySet();
		Iterator<Student>i=s.iterator();
		while(i.hasNext())
		{
			Student  st=i.next();// gets  the key
			Course  cr=h.get(st);// get the  value
System.out.println(st.name+"   from   "+st.city+
		"   studying   "+cr.getCname()+"  in  "+cr.getSem()+ "    Semester");			
		}
	}
}
