package praveen;

import java.util.*;

class Person implements  Comparable<Person>
{
	String  name;
	int age;
	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	@Override
	public int compareTo(Person o) {
		return  o.name.compareTo(name);
	}
	
}
class Address
{
	String  city, state;

	public Address(String city, String state) {
		super();
		this.city = city;
		this.state = state;
	}
	
}
public class Five {
public static void main(String[] args) {
	Person p1=new Person("naveen", 22);
	Person p2=new Person("Arvind", 20);
	Person p3=new Person("kamal", 23);
	Address  s1=new Address("pune", "maharashtra");
	Address  s2=new Address("surat", "gujrat");
	
	Address  s3=new Address("jaipur", "rahasthan");
	TreeMap<Person, Address>  t=new TreeMap<Person, Address>();
	t.put(p1, s1);t.put(p2, s2);t.put(p3, s3);
	Set<Person>  set=t.keySet();
Iterator<Person> i=set.iterator();
while(i.hasNext())
{
	Person  pp=i.next();
	Address add=t.get(pp);
	System.out.println(pp.name+"  aged "+pp.age+"    years staying in "+add.city+"   in  "+add.state);
}
	
}
}
