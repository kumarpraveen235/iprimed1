package praveen;

import java.util.*;

public class Two {
public static void main(String[] args) {
	LinkedHashMap<String, Integer>   l=new LinkedHashMap<String, Integer>();
	l.put("kathick", 99);
	l.put("nagesh", 79);
	l.put("nagraj", 89);
	l.put(null, 99);
	l.put("santosh", 59);
	//l.remove("nagraj");
	System.out.println(l);
	System.out.println("value  pf nagesh  "+l.get("nagesh"));
	System.out.println(l.containsKey("nagraj"));
	System.out.println(l.containsValue(79));
	System.out.println("Iterating");
	Set<String> s=l.keySet();
	Iterator<String>  i=s.iterator();
	while(i.hasNext())
	{
		String  str=i.next();
		System.out.println(str+"   "+l.get(str));
	}
}
}
