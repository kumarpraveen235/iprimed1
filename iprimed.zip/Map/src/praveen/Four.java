package praveen;
import java.util.*;
public class Four {
public static void main(String[] args) {
	TreeMap t=new TreeMap<Integer, String>();
	t.put(33, null);
	t.put(33, null);t.put(333, "ab");t.put(331, "abc");t.put(313, "aa");t.put(133, "ac");
	t.put(-33, "a");t.put(833, "ca");t.put(31, "acc");t.put(-3, "aaa");t.put(233, "abc");
System.out.println(t);
System.out.println(t.headMap(313));
System.out.println(t.tailMap(31));
System.out.println(t.subMap(33, 333));
}
}
