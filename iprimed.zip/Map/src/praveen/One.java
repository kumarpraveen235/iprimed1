package praveen;
import java.util.*;
public class One {
public static void main(String[] args) {
	HashMap  h=new HashMap();
	h.put("vishal", 86790);
	h.put(8697, 10000);
	h.put(868.99, 10000);
	h.put("vijay", 10000);
	h.put("vijay", 44790);
	h.put(null, null);
	System.out.println(h);
}
}
