package praveen;
class pqr1
{
	  int s=1;
	     void   m()
	     {
	    	 System.out.println("Hi");
	     }
	}
public class pqr extends   pqr1 {
	int  s=2;
	@Override
	void m()
	{
		System.out.println("Hello");
	}
	
public static void main(String[] args) {
	pqr1   p=new pqr();   // upcasting;
	pqr  pp=new pqr();
	   pp=(pqr)p;//   down casting
	   System.out.println(pp.s);
	   pp.m();
}
}
