package praveen;
class A{
	void m()
	{
		System.out.println("i am  in A");
	}
}
class B extends   A{
	@Override
	void m()
	{
		System.out.println("i am  in B");
	}
}
class C extends   B{
	@Override
	void m()
	{
		System.out.println("i am  in C");
	}
}
public class Program {
public static void main(String[] args) {
	A aa=new A();
	B bb=new B();
	C cc=new C();
	A r;
	r=aa;
	r.m();
	r=bb;//  upcasting
	r.m();
	r=cc;//   upcasting
	r.m();
}
}
