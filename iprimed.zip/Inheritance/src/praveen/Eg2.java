package praveen;

 class Eg3 {
       int a=100;
       
}
class   Eg2 extends  Eg3
{
	    int a=500;
	    
	    Eg2()
	    {
	    	System.out.println(a+"\t"+super.a);
	    }
	    public static void main(String[] args) {
			Eg2 e=new Eg2();
			
		}
}
