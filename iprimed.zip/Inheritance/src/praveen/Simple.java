package praveen;

class SuperSimple
{
	   int  a,b;
    
	public SuperSimple(int a, int b) {
		super();
		this.a = a;
		this.b = b;
		
	}
	   
}
class SubSimple extends  SuperSimple{
	int c;

	public SubSimple(int a, int b, int c) {
		super(a, b);
		this.c = c;
		System.out.println(a+b+c);
	}

	
}

public class Simple {
public static void main(String[] args) {
	SubSimple   ss=new SubSimple(22,11,44);
	
}
}
