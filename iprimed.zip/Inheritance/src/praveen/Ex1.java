package praveen;

 class Ex2 {
 Ex2()
 {
	   // super(); // calls   Object class  default constructor   which has EMPTY  implementation
	   System.out.println("super  con");
 }
}
 class Ex1 extends  Ex2
 {
	     Ex1()
	     {
	    	//  super();//   it is  implicittely   supplied by  compiler 
	    	  // calls    Ex2  class  default cosntructor
	    	 System.out.println("sub conn");
	     }
	     public static void main(String[] args) {
			Ex1  e=new Ex1();
		}
 }