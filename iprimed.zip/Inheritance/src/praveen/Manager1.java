package praveen;
class Emp1
{
	   void m()
	   {
		   System.out.println("I am  emp");
	   }
}
public class Manager1 extends  Emp1 {
	@Override
	 void m()   //  overridden
	   {
		   System.out.println("I am  manager");
	   }
   public static void main(String[] args) {
	      Manager1   mm=new Manager1();
	         mm.m();
}
}
