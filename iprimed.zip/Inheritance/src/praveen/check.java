package praveen;
class check1
{
	 public check1() {
	System.out.println("super   con");	
	 	 }
	 
 {System.out.println("int  block of super");}
}
public class check  extends   check1 {
  public check() {
	super();
	System.out.println("sub con");
}
  {System.out.println("init   block  of sub");
}
public static void main(String[] args) {
	
check1   cc1=new check1();
	  check   cc=new check();
}
}

