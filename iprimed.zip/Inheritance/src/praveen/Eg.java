package praveen;

 class Eg1{
	    int  a=100;
         void m()
         {
        	 System.out.println("Hi");
         }
}
 class   Eg extends Eg1
 {
	    int a=110;
	 @Override
	 void m()
	 {
		 System.out.println("hello");
	 }
	 public static void main(String[] args) {
		    Eg1 e=new Eg();// upcasting
		        e.m();
		        System.out.println(e.a);
	}
 }
