package praveen;

class Ex4 {
	int i;
	public   Ex4()
	{
		System.out.println("I am super default");
	}
	public Ex4(int i) {
		this.i = i;
		System.out.println(i);
	}
}
class Ex3 extends  Ex4
{
	public   Ex3()
	{
		
		System.out.println("I am sub default");
	}
   public  Ex3(int j)
   {
	   super(j);// invokes  1  parameter   Ex4's   constructor
   }
   public static void main(String[] args) {
	   Ex3   ee=new Ex3();
	Ex3    e=new Ex3(100);
}
}
