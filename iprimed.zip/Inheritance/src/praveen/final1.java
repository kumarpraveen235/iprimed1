package praveen;

class  final1
{
	       final  int a;//  blank final  var 
	       
	       public   final1() {
	    	   a=10;
		System.out.println("I am con  "+a);
		}

	
	//	  { System.out.println("init"); }
		 
	       public static void main(String[] args) {
			final1  f=new final1();
		}
	       
}


// constructors  cannot have  modifiers  like  static  final  and abstract
// constructors  can be public  protected   private and  default