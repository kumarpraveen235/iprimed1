package praveen;
import java.util.*;
class Shape
{
	   double  dim1, dim2;

	public Shape(double dim1, double dim2) {
		super();
		this.dim1 = dim1;
		this.dim2 = dim2;
	}
	   double   area()
	   {
		   return  0.0;
	   }
}
class Rect extends  Shape
{
	public Rect(double  dim1, double dim2)
	{
		   super(dim1, dim2);
	}
	@Override
	double   area()
	   {
		   return  dim1*dim2;
	   }

}
public class Triangle extends  Shape {
	public Triangle(double  dim1, double dim2)
	{
		   super(dim1, dim2);
	}
	@Override
	double   area()
	   {
		   return  0.5*dim1*dim2;
	   }

	public static void main(String[] args) {
		Scanner  sc=new Scanner(System.in);
	   System.out.println("enter dim1  dim2");
	   double d1=sc.nextDouble();
	   double d2=sc.nextDouble();
	   Shape   r=new Rect(d1, d2);
	   System.out.println("Area of rect "+r.area());
	   Triangle   t=new Triangle(d1, d2);
	   System.out.println("Area  of tri "+t.area());
	     sc.close();
	}
}
