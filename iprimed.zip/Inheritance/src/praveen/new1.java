package praveen;

 class new2 {
   
	final    void  m( int a)
	    {
	    	    System.out.println(a);
	    }
}
 class   new1 extends new2{
	     void  m( int a, int b)
	    {
	    	    System.out.println(a+b);
	    }
	    
	 
	    public static void main(String[] args) {
		  new1   nn=new new1();
		     nn.m(10);
		     nn.m(3,2);
		}
 }
