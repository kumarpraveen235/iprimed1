package praveen;

 class Eg7 {
     int a=100;
     void  m()
     {
    	 System.out.println(a);
     }
}
 class Eg8 extends   Eg7
 {
	 int a=101;
	 @Override
     void  m()
     {
		 super.m();
    	 System.out.println(a);
     }
 }
 class Eg6 extends   Eg8
 {
	 int a=102;
	 @Override
     void  m()
     {
		 super.m();
    	 System.out.println(a);
     } 
	 public static void main(String[] args) {
		Eg6  e=new Eg6();   e.m();
	}
	 
}