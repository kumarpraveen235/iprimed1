package praveen;
class X
{
	   void m()
	   {
		   System.out.println("Hi");
	   }
}
class Y extends   X
{
	@Override
	 void m()
	   {
		   System.out.println("Hello");
	   }
}
public class dOWN {
public static void main(String[] args) {
	X  xx=new Y(); // upcasting
	Y yy=new Y();//    SUB CLASS REF variable is yy
	yy=(Y)xx;//  downcasting  sub  class ref   var  refers to super class obj
	yy.m();
	
}
}
