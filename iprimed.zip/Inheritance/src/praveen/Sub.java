package praveen;

class Sup
{
	 protected   void m()
	    {
	    	System.out.println(" iam  super");
	    }
}

public class Sub extends   Sup {

	public void m()
	    {
	    	System.out.println(" iam  sub");
	    }
	public static void main(String[] args) {
		Sub ss=new Sub();
		   ss.m();
	}
}
