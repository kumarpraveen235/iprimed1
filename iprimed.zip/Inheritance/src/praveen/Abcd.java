package praveen;

public class Abcd {
     int a;
     Abcd()
     {
    	 System.out.println("value  of  a  "+a);
     }
     { System.out.println("i am  init");  a=10;}
     public static void main(String[] args) {
		Abcd  a=new Abcd();
	}
}
