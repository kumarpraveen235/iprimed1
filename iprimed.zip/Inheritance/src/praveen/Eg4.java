package praveen;

 class Eg5 {
	 
	 void  m()
	 {
		 System.out.println("Hi");
	 }

}
 class Eg4 extends  Eg5
 {
	 @Override
	 void m()
	 {
		    super.m();
		 System.out.println("hello");
	 }
	 public static void main(String[] args) {
		Eg4   e=new Eg4();
		e.m();
	}
 }
