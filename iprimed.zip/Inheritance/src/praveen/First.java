package praveen;
class  Emp
{
	   int salary=20000;
	   String name="vijay";
	   void m()
	   {
		   System.out.println("I am   emp");
	   }
}
class Manager  extends  Emp
{
	   int   bonus=1000;
	   void m1()
	   {
		   System.out.println(" iam  manager");
	   }
}
public class First {
    public static void main(String[] args) {
		Manager mg=new Manager();
		   System.out.println("Total  sal  "+(mg.salary+mg.bonus));
		   mg.m();mg.m1();
	}
}
