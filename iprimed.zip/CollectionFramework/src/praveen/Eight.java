package praveen;

import java.util.Iterator;
import java.util.LinkedList;

public class Eight {
public static void main(String[] args) {
	LinkedList<Integer> ll=new LinkedList<Integer>();
	ll.add(10);    // 300 4 
	ll.addFirst(100);
	ll.add(1,5);
	ll.set(2, 300);
	ll.add(4);
	ll.remove(1);
	ll.removeFirst();
	/*
	 * for(int i:ll) { System.out.println(i); }
	 */
	
	Iterator<Integer> i=ll.descendingIterator();
	while(i.hasNext())
	{
		System.out.println(i.next());
	}
	
	System.out.println();System.out.println(ll.getFirst());
}
}
