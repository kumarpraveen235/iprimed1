package praveen;

import java.util.ArrayList;
import java.util.Vector;

public class Eleven {
public static void main(String[] args) {
	Vector<String> v=new Vector<String>();
	v.add("vinay");

	v.add("vikas");

	v.add("vishwa");

	v.add("vinod");

	v.add("vijay");
	ArrayList<String> al=new ArrayList<String>(v);
	for(String st:al)
	{
		System.out.println(st);
	}
	
}
}
