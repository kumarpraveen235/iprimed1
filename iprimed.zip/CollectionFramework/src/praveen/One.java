package praveen;
import java.util.*;
public class One {
public static void main(String[] args) {
	ArrayList  al=new ArrayList();//non generic array list
	al.add(new Integer(10));al.add(0, new Integer(110));
	al.add(new String("vijay"));
	al.add(new Character('h'));
	al.add(true);
	al.add(null);
	al.add(10);
	al.add(10.67);
	System.out.println(al);
	System.out.println("3rd index  "+al.get(3));
	al.set(6, 6.6f);
	al.remove(2);//   2 is index
	System.out.println(al);
	al.remove(new Integer(110));
	System.out.println(al);
}
}
