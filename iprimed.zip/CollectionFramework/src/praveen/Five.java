package praveen;
import java.io.ObjectInputStream.GetField;
import java.util.*;
public class Five {
  public static ArrayList<Integer>  get()
  {
	  ArrayList<Integer>al=new ArrayList<Integer>();
	  al.add(200);al.add(300);al.add(600);
	  al.add(100);al.add(400);al.add(500);
      return al;
  }
  public static void main(String[] args) {
	ArrayList<Integer> a=get();
	ListIterator<Integer> i=a.listIterator();
	while(i.hasNext())
	{
		System.out.println(i.next());
	}
	System.out.println("REVERSE");
	while(i.hasPrevious())
	{
		System.out.println(i.previous());
	}	
}
}
