package praveen;
import java.util.*;
public class Nine {
public static void main(String[] args) {
	ArrayList<Double> al=new ArrayList<Double>();
	al.add(34.22);
	al.add(64.22);
	al.add(14.22);
	al.add(24.22);
	LinkedList<Double> ll=new LinkedList<Double>(al);
	for(double d:ll)
	{
		System.out.println(d);
	}
}
}
