package praveen;

import java.util.ArrayList;

public class three {
public static void main(String[] args) {
	ArrayList al=new ArrayList();
	al.add(32);al.add(20);al.add(62);al.add(12);
	al.add(2);al.add(28);al.add(72);al.add(22);
   int s=0;
   for(Object  o:al)
   {
	   s=s+(int)o;
	   
   }
   System.out.println(s);

}
}
