package praveen;

import java.util.ArrayList;

public class Two {
public static void main(String[] args) {
	ArrayList al=new ArrayList();
	al.add("ajay");
	al.add("arun");
	al.add("amar");
	
	al.add("akshay");
	for(Object o:al)
	{
		System.out.println(o);
	}
	System.out.println("Using for loop");
	for(int i=0;i<al.size();i++)
	{
		System.out.println(al.get(i));
	}
}
}
