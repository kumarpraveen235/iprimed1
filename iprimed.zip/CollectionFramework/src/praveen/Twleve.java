package praveen;
import java.util.*;
public class Twleve {
public static void main(String[] args) {
	ArrayList<String> al=new ArrayList<String>();
	al.add("Mohan");
	al.add("sudheer");
	al.add("Abdul");
	al.add("rafeeq");
	al.add("john");
	al.add("Micheal");
	al.add("Jones");
	Collections.sort(al);
	System.out.println(al);
	Collections.reverse(al);
	System.out.println(al);
}
}
