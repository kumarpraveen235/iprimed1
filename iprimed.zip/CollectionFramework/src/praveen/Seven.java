package praveen;

import java.util.ArrayList;

public class Seven {
public static void main(String[] args) {
	ArrayList<String> al=new ArrayList<String>();
	al.add("pradeep");al.add("praveen");al.add("pramod");
	al.add("prashant");al.add("prakash");
	ArrayList<String> al1=new ArrayList<String>();
	al1.add("pradeep");al1.add("praveen");al1.add("pramod");
	al1.add("pavan");al1.add("piyush");
	//al.addAll(al1);
	//al.removeAll(al1);//   al is  invoking al1 is specified
	//al.retainAll(al1);
	System.out.println(al.contains("pradeep"));
	/*
	 * for(String a:al) { System.out.println(a); }
	 */
	al.clear();al1.clear();
	System.out.println(al+"   "+al1);
}
}
