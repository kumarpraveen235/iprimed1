package praveen;
import java.util.*;
public class Four {
 public static void   show()
 {
	       ArrayList<String>  al=new ArrayList<String>();// String(generic) array list
	       al.add("gauri");
	       al.add("deepika");
	       al.add("deepa");
	       al.add("asha");
	       al.add("geeta");
	       String   str=al.get(3);
	       System.out.println(str);
	       for(String   s:al)
	       {
	    	   System.out.println(s);
	       }
	       
 }
 public static void main(String[] args) {
	       show();
}
}
