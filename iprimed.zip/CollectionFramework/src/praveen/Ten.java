package praveen;
import java.util.*;
public class Ten {
public static void main(String[] args) {
	Vector<Integer> v=new Vector<Integer>(3,3);
	//  once  capacity is  exceeded  increment added  to capacity
//	System.out.println(v.size()+"   "+v.capacity());
	v.addElement(11);	v.addElement(12);	v.addElement(13);
	//System.out.println(v.size()+"   "+v.capacity());	
	v.addElement(14);
//	System.out.println(v.size()+"   "+v.capacity());
	System.out.println(v);
	System.out.println(v.elementAt(2));
	v.insertElementAt(100, 1);System.out.println(v);
	v.removeElementAt(1);
	System.out.println(v);
	Enumeration<Integer> e=v.elements();
	while(e.hasMoreElements())
	{
		System.out.println(e.nextElement());
	}
}
}
