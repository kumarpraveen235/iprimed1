package praveen;
import java.util.*;
public class Sixteen {
public static void main(String[] args) {
	//Deque<Integer> ad=new ArrayDeque<Integer>();//  upcasting
	//List<Integer> al=new ArrayList<Integer>();//upcasting
	ArrayDeque<Integer> ad=new ArrayDeque<Integer>();
	  ad.offer(100);
	  ad.add(101);
	  ad.addFirst(106);
	  ad.offer(108);
	  ad.add(107);
	  ad.offer(105);
	  ad.add(104);
	  System.out.println(ad);
	  System.out.println("top  "+ad.peek());
	  ad.poll();
	  for(int i:ad)
	  {
		  System.out.println(i);
	  }
	  System.out.println("reverse order");
	  Iterator<Integer>  ii=ad.descendingIterator();
	  while(ii.hasNext())
	  {
		  System.out.println(ii.next());
	  }
}
}
