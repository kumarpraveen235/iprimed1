package praveen;

import java.util.Collections;
import java.util.Vector;

public class Thirteen {
public static void main(String[] args) {
	Vector<Integer> v=new Vector<Integer>();
	v.add(1);
	v.add(17);
	
	v.add(-101);
	v.add(-41);
	
	v.add(19);
	v.add(107);
	
	v.add(147);
	Collections.sort(v);
	System.out.println(v);
	System.out.println("element  found  at  "+
	Collections.binarySearch(v, 19)+"   position");
	
}
}
