package praveen;

import java.util.*;

class Book
{
	 int id;
	 String name, author;
	 double price;
	public Book(int id, String name, String author, double price) {
		super();
		this.id = id;
		this.name = name;
		this.author = author;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", name=" + name + ", author=" + author + ", price=" + price + "]";
	}
	 
}
class  AuthorComp implements Comparator<Book>
{

	@Override
	public int compare(Book o1, Book o2) {
		return o1.author.compareTo(o2.author);
	}
	
}
class  PriceComp implements Comparator<Book>
{

	@Override
	public int compare(Book o1, Book o2) {
		if(o1.price==o2.price) return 0;
		if(o1.price > o2.price) return 1;
		else return-1;
	}
	
}
public class Fifteen {
public static void main(String[] args) {
	ArrayList<Book> al=new ArrayList<Book>();
	al.add(new Book(1,"java", "Peter",798.80));
	al.add(new Book(2,"html", "davis",398.80));
	al.add(new Book(3,"dotnet", "Albert",798.79));
	al.add(new Book(4,"python", "mark",800.00));
	al.add(new Book(5,"spring", "stephen",777.40));
	System.out.println("sort on author");
	Collections.sort(al, new AuthorComp());
	for(Book b:al)
	{
		System.out.println(b);
	}
	System.out.println("sort on price");
	Collections.sort(al, new PriceComp());
	for(Book b:al)
	{
		System.out.println(b);
	}
}
}
