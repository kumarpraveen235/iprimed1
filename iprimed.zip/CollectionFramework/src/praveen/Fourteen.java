
package praveen;
import java.util.*;
class  Person implements Comparable<Person>{
	 int id;
	 String name;
	 int age;
	public Person(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", age=" + age + "]";
	}
	/*
	 * @Override public int compareTo(Object o) { Person p=(Person)o;// downcasting
	 * if(age>p.age) return 1;// age is invoking obj p.age is specified object
	 * if(age==p.age) return 0; else return -1;
	 * 
	 * }
	 */
	@Override
	public int compareTo(Person o) {
		return  o.name.compareTo(name);
	}
	 
}
public class Fourteen {
public static void main(String[] args) {
	ArrayList<Person> al=new ArrayList<Person>();
	al.add(new Person(1, "santosh",22));
	al.add(new Person(2, "sooraj",26));
	al.add(new Person(3, "suman",21));
	al.add(new Person(4, "sudeep",24));
	al.add(new Person(5, "sandeep",27));
	Collections.sort(al);
	for(Person p:al)
	{
		System.out.println(p);
	}
}
}
