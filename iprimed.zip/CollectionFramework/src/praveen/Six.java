package praveen;
import java.util.*;
class Product
{
	  int id;
	  String name;
	  String category;double  price;

	public Product(int id, String name, String category, double price) {
		super();
		this.id = id;
		this.name = name;
		this.category = category;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", category=" + category + ", price=" + price + "]";
	}
	  
}
public class Six {
public static void main(String[] args) {
	Product p1=new Product(1, "laptop","computer", 78780.00);
	Product p2=new Product(2, "pencil","stationary", 20.00);
	Product p3=new Product(3, "fridge","electronics", 40000.00);
	Product p4=new Product(4, "tubelight","electrical", 300.67);
	LinkedList<Product>  al=new LinkedList<Product>();
	al.add(p1);al.add(p2);al.add(p3);al.add(p4);
	al.remove(p1);
	Iterator<Product> i=al.iterator();
	while(i.hasNext())
	{
		Product  p=i.next();
		System.out.println(p);
	}
}
}
