package praveen;

public class SIX {
public static void main(String[] args) {
	System.out.println(String.valueOf(637.5786f));
	System.out.println(String.valueOf(true));
	
	String  ss="i am from  bangalore";
	byte[]  b=ss.getBytes();
	for(byte  bb:b)
	{
		System.out.print((char)bb+" ");
	}
	
}

}
