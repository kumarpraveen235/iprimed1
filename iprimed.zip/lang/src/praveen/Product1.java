package praveen;
class Product
{
	  int id;String name;int price;

	public Product(int id, String name, int price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}

	
	  @Override public String toString() 
	  { 
		  return "Product [id=" + id + ", name=" +
	  name + ", price=" + price + "]";
		  }
	 
	    

	}
public class Product1 {
public static void main(String[] args) {
	Product p=new Product(1, "laptop", 46759);
	System.out.println(p);
	//p.d();
}
}
