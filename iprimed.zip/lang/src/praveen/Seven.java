package praveen;
import java.util.*;
public class Seven {
public static void main(String[] args) {
	Scanner  sc=new Scanner(System.in);
	System.out.println("enter the String");
	String  s=sc.nextLine().toLowerCase();
	char []   c=s.toCharArray();
	int count=0;
	for(char cc:c)
	{
		switch(cc)
		{
		case  'a' : 
		case 'e':
		case  'i' : 
		case 'o':
		case  'u' : 
		count++;
		}
	}
	System.out.println("No  of  vowels  "+count);
}
}
