package praveen;
import  java.util.*;
public class Five {
public static void main(String[] args) {
	Scanner  sc=new Scanner(System.in);
	System.out.println("enter  String");
	String s=sc.nextLine();
	//System.out.println(s);
	int start=10, end=14;
	char[] buf=new char[7];
	s.getChars(start, end, buf, 3);
	System.out.println(buf);
}
}
