package praveen;

public class Sb3 {
public static void main(String[] args) {
	StringBuffer sb=new StringBuffer("this is java training");
	//sb.insert(8, "core");
	//sb.delete(7, 12);
	//sb.replace(8, 13, "python");
	System.out.println(sb);
  StringBuffer  s2=new StringBuffer("welcome");
  StringBuffer  s3=new StringBuffer("welcome");
  System.out.println(s2.compareTo(s3));
  if(String.valueOf(s2).equals(String.valueOf(s3))==true)
  {
	  System.out.println("equal");
  }
  else
  {
	  System.out.println("not");
  }
}



}
