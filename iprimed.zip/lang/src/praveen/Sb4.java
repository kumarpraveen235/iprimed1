package praveen;
import  java.util.*;
public class Sb4 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter string");
	String  s=sc.next();
	StringBuilder  sb1=new StringBuilder(s);
	StringBuilder sb2=sb1.reverse();
	StringBuilder  sb3=new StringBuilder(s);
	if(String.valueOf(sb1).equals(String.valueOf(sb3))==true)
	{
		System.out.println("pallindrome");
	}
	else
	{
		System.out.println("Not a  pallindrome");
	}
}
}
