package praveen;

public class Sb1 {
public static void main(String[] args) {
	StringBuffer   sb=new StringBuffer("hellohellohello");
	//sb.append("i am stying in bangalore in karanataka state");
	System.out.println(sb+"   "+sb.capacity());
}
}
