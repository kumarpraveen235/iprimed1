package praveen;

public class Sb2{
public static void main(String[] args) {
	StringBuffer   sb=new StringBuffer("hello");
	sb.setCharAt(1, 'i');//    hillo
	sb.setLength(2);// hi
	System.out.println(sb);
}
}
