package praveen;

public class Four {
public static void main(String[] args) {
	String  s="thisis chennai city";
	String  a="i am  getting 1 salary with 1 bonus";
	        String[] ss=  s.split("\\s");
	        for(String sss:ss)
	        {
	        	System.out.println(sss);
	        }
	        String[] ss1=  a.split("\\d");
	        for(String sss:ss1)
	        {
	        	System.out.println(sss);
	        }
}
}
