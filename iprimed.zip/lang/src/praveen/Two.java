package praveen;

public class Two {
public static void main(String[] args) {
	String s="welcome";      // created  in string constant  pool
	String s1="WELCOME";
	String s3=new String("welcome");// created  in HEAP area
	String  s4="deepa";
	String s5="deepakumari";
	System.out.println(s.equals(s1));   // false
	System.out.println(s.equals(s3));// t
	System.out.println(s.equalsIgnoreCase(s1));//t
	System.out.println(s==s3);// f
	System.out.println(s4.compareTo(s5));
	
	//System.out.println((int)'u');
	
}
}
