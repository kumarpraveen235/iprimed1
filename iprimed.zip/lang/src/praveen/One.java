package praveen;

public class One {
public static void main(String[] args) {
char  c[]= {'p','u','n','e'};
String   s=new String(c);
System.out.println(s);
String   ss="naveen";
ss.concat("kumar");
System.out.println(ss);
}
}
