package praveen;

public class Sb {
public static void main(String[] args) {
	StringBuffer   sb=new StringBuffer("ajay");
	StringBuffer   sb1=new StringBuffer("ajay");
	System.out.println(sb+"   "+sb1);
	System.out.println(sb.equals(sb1));//false
	System.out.println(sb==sb1);// false
	//sb=sb1;
//	System.out.println(sb.equals(sb1));	
	// in the  above  example   StringBuffer  does not contains
	// equals  method.  The   above   equals() method is of Object class
	//   which comapres  the  references of objects. In the above eg
//Stringbuffer  objects are  created using new  key word  which
	// goes into heap area Both have  diff memory addresses
	//so  Object class equals() method  returns false
	
}
}
