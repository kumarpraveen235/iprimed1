package praveen;

public class Three {
public static void main(String[] args) {
	System.out.println("bangalore".charAt(3));
	String   s="today is friday";
	System.out.println(s.indexOf("day"));
	System.out.println(s.lastIndexOf("day"));
	System.out.println("bangaloreCity".substring(3, 8));
	System.out.println(s.length());
	System.out.println(2+2+"chennai"+2+2);
	System.out.println(s.intern());
	//  creates   a  duplicate  String in string constat pool
	
	System.out.println("vijay".startsWith("vij"));
	System.out.println("kumar".toUpperCase());
	System.out.println("         SANTOSH".trim());
	System.out.println("hello".replace('l', 'p'));
}
}
