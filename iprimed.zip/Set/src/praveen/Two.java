package praveen;

import java.util.*;

class Student
{
	   int id;
	   String name;
	   int age;
	public Student(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	@Override
	public   boolean  equals(Object o)
	{
		Student  s=(Student)o;
		if(id==s.id && name.equals(s.name)&& age==s.age)
		{
			return  true;
		}
		else
		{
			return false;
		}
	}
	@Override
	public  int hashCode()
	{
		int  r=1;
		r=r+id;
		r=r+name.hashCode();
		r=r+age;
		return r;
	}
	
	/*
	 * @Override public String toString() { return "Student [id=" + id + ", name=" +
	 * name + ", age=" + age + "]"; }
	 */
	
}
public class Two {
public static void main(String[] args) {
	Student s1=new Student(1, "amar", 22);
	Student s2=new Student(11, "amar", 22);
	Student s3=new Student(-15, "amar", 22);
	Student s4=new Student(-15, "amar", 22);
	System.out.println(s1+"    "+s2+"   "+s3+"    "+s4);
	System.out.println(s1.hashCode()+"   "+s2.hashCode()+"    "+s3.hashCode()+"    "+s4.hashCode());
	LinkedHashSet<Student>  h=new LinkedHashSet<Student>();
	h.add(s1);h.add(s2);h.add(s3);h.add(s4);
	Iterator<Student> i=h.iterator();
	while(i.hasNext())
	{
		Student ss=i.next();
		System.out.println(ss.id+"   "+ss.name+"    "+ss.age);
	}
}
}
