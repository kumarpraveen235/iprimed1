package praveen;

import java.util.*;
class Product implements Comparable<Product>
{
	 int id;
	 String name;
	int price;
	public Product(int id, String name, int price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	@Override
	public int compareTo(Product o) {
		return  name.compareTo(o.name);
	}
	
}
public class Five {
  public static void main(String[] args) {
	TreeSet<Product>  t=new TreeSet<Product>();
	t.add(new Product(1, "laptop", 65650));
	t.add(new Product(2, "Mobile", 14650));
	t.add(new Product(3, "Iphone", 55650));
	for(Product p:t)
	{
		System.out.println(p);
	}
}
}
