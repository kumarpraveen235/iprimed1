package praveen;

import java.util.*;

class Book
{
	 int id;
	 String name, author;
	 double price;
	public Book(int id, String name, String author, double price) {
		super();
		this.id = id;
		this.name = name;
		this.author = author;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", name=" + name + ", author=" + author + ", price=" + price + "]";
	}
	 
}
class  AuthorComp implements  Comparator<Book>
{

	@Override
	public int compare(Book o1, Book o2) {
		return o1.author.compareTo(o2.author);
	};
	   
}
class  PriceComp1 implements  Comparator<Book>
{

	@Override
	public int compare(Book o1, Book o2) {
		if(o1.price==o2.price) return 0;
		if(o1.price > o2.price) return 1;
		else return -1;
			
	};
	   
}
public class Seven {
public static void main(String[] args) {
	HashSet<Book> h=new HashSet<Book>();
	h.add(new Book(1, "java", "martin", 700.68));

	h.add(new Book(2, "Spring", "Peter", 1000.53));

	h.add(new Book(3, "Angular", "James", 900.98));

	h.add(new Book(4, "Css", "robert", 400.55));

	h.add(new Book(5, "html", "Backer", 300.18));
	List<Book> l=new ArrayList<Book>(h);// converts set to list
	Collections.sort(l, new AuthorComp());
	System.out.println("sort on author");
	for(Book b:l)
	{
		System.out.println(b);
	}
	Collections.sort(l, new PriceComp1());
	System.out.println("sort on price");
	for(Book b:l)
	{
		System.out.println(b);
	}
}
}
