package praveen;
import java.util.*;
public class Four {
public static void main(String[] args) {
	HashSet<Integer> h=new HashSet<Integer>();
	h.add(3);h.add(30);h.add(37);h.add(13);h.add(-3);
//	TreeSet<Integer> t=new TreeSet<Integer>(h);
	//System.out.println(t);
	List<Integer>  l=new ArrayList<Integer>(h);
	Collections.sort(l);
	System.out.println(l);
	
}
}
