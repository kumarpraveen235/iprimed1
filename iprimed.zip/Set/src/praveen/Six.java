package praveen;

import java.util.*;
class Product1
{
	 int id;
	 String name;
	int price;
	public Product1(int id, String name, int price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
}
class  PriceComp implements Comparator<Product1>
{

	@Override
	public int compare(Product1 o1, Product1 o2) {
	    	
	if(o1.price==o2.price) return 0;
	if(o1.price > o2.price) return 1;
	else return -1;
	
	}
	
}
public class Six {
  public static void main(String[] args) {
	TreeSet<Product1>  t=new TreeSet<Product1>(new PriceComp());
	t.add(new Product1(1, "laptop", 65650));
	t.add(new Product1(2, "Mobile", 14650));
	t.add(new Product1(3, "Iphone", 55650));
	for(Product1 p:t)
	{
		System.out.println(p);
	}
}
}
