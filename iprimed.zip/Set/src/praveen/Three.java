package praveen;

import java.util.TreeSet;

public class Three {
public static void main(String[] args) {
	TreeSet<String> t=new TreeSet<String>();
	t.add("Abhi");
	t.add("ABHAY");
	t.add("arun");
	t.add("AMan");
	t.add("Amol");
	t.add("ashish");
	t.add("ADITYA");
	t.add("ashwin");
	System.out.println(t);
	System.out.println(t.headSet("Amol")); 
	System.out.println(t.tailSet("AMan"));
	System.out.println(t.subSet("ADITYA", "ashish"));
	}
}
