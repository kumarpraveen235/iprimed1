package praveen;
import java.util.*;
public class One {
public static void main(String[] args) {
	HashSet<Integer>  h=new HashSet<Integer>();
	h.add(new Integer(98));
	h.add(new Integer(100));	h.add(new Integer(101));
	h.add(new Integer(5));	h.add(new Integer(102));	
	h.add(new Integer(103));
	h.add(null);	h.add(null);
	
	System.out.println(h);
	h.remove(new Integer(100));
	Iterator<Integer> i=h.iterator();
	while(i.hasNext())
	{
		System.out.println(i.next());
	}
}
}
